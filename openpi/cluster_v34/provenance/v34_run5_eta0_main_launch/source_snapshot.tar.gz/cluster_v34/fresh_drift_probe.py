"""Measure the FRESH-INIT core's per-segment fast-weight drift ||M_t - m0|| on real data.

Sizes the plan-5.7 drift_radius escalation: the radius must sit comfortably above the drift a
healthy (init) core accumulates over a full segment, so it only prevents the pathological
excursions (v34_run1 ckpt-2750 core reached 17.6 and kept growing). Runs on a 24GB card
(bf16 tower, batch 2, forward + writes only).
"""
# ruff: noqa: I001, B023
import pyarrow.parquet as pq  # noqa: F401
import torch  # noqa: F401

import dataclasses
import sys

import jax
import jax.numpy as jnp
import numpy as np

sys.path.insert(0, "/iris/u/kewalk/memory_project/openpi/scripts")
from v34_init_scale import build_init_model

import openpi.models.model as _model
import openpi.models.memory as _memory
import openpi.shared.nnx_utils as nnx_utils
import openpi.training.config as _config
import openpi.training.data_loader as _data_loader

BATCHES = 3


def main():
    config = _config.get_config("pi05_yam_mem_v34")
    config = dataclasses.replace(config, batch_size=2, num_workers=0)
    model = build_init_model(config, bf16_tower=True)
    model.eval()

    interface_step = nnx_utils.module_jit(model.v32_memory_interface_step)
    write_step = nnx_utils.module_jit(model.memory.write)
    loader = _data_loader.create_data_loader(config, shuffle=True, num_batches=BATCHES)

    final_drifts = []
    for batch_index, (obs, _actions) in enumerate(loader):
        b, t = obs.seq_step_mask.shape
        valid = np.asarray(obs.seq_step_mask)
        state = model.memory.init_state(b)
        print(f"\n#### batch {batch_index}: b={b} T={t} valid={valid.sum(1).tolist()}")
        for step in range(t):
            if not valid[:, step].any():
                break
            obs_dict = {
                "image": {k: v[:, step] for k, v in obs.images.items()},
                "image_mask": {k: v[:, step] for k, v in obs.image_masks.items()},
                "state": obs.state[:, step],
                "tokenized_prompt": obs.tokenized_prompt[:, step],
                "tokenized_prompt_mask": obs.tokenized_prompt_mask[:, step],
                "token_state_mask": obs.token_state_mask[:, step],
            }
            out = interface_step(_model.Observation.from_dict(obs_dict), state)
            state, aux = write_step(state, out["write_tokens"])
            drift = jax.tree.map(
                lambda fw, m0: fw - jnp.broadcast_to(m0.value, fw.shape),
                state.fast_weights,
                dict(model.memory.m0),
            )
            norms = np.asarray(_memory._tree_norm(drift))  # noqa: SLF001
            if step % 4 == 0 or step == t - 1:
                print(
                    f"step {step:3d}: drift per-sample={np.round(norms, 3).tolist()} "
                    f"inner_grad_max={np.asarray(aux['grad_norm']).max():.3g} "
                    f"clip_min={np.asarray(aux['clip_factor']).min():.3g}"
                )
            last = norms
        final_drifts.extend(last.tolist())
    arr = np.asarray(final_drifts)
    print(
        f"\nFRESH-CORE END-OF-SEGMENT DRIFT: n={len(arr)} median={np.median(arr):.3f} "
        f"p95={np.percentile(arr, 95):.3f} max={arr.max():.3f}"
    )
    print("suggested drift_radius = 2-3x the p95 above")


if __name__ == "__main__":
    main()
