#!/bin/bash
# v3.4 real training run (plan 9 step 5): 20k steps, save every 250, 4x H100 FSDP.
# Fresh from official pi05_base; never resume a v3.x checkpoint. If the enclosing slurm
# allocation ends, relaunch with --resume instead of --overwrite.
# v34_run3: run2 hit the same cycle at ~1300 with the blast redirected into the VLM via the
# write k/v backward; kv_cotangent_clip=1.0 closes that path. run1 killed at ~2.8k by the recurrent-backward explosion limit cycle; this run
# carries the two guardrails (state_cotangent_clip=10, memory_grad_clip=5). Watch
# memory_grad_norm in wandb.
set -x
cd /iris/u/kewalk/memory_project/openpi || exit 1
export HOME=/iris/u/kewalk
export HF_HOME=/iris/u/kewalk/.cache/huggingface
export OPENPI_DATA_HOME=/iris/u/kewalk/.cache/openpi
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.92
exec .venv/bin/python scripts/train.py pi05_yam_mem_v34 \
  --exp-name v34_run3 \
  "$@" \
  --batch-size 12 \
  --fsdp-devices 4 \
  --seed 42
