"""Recurrent-chain backward amplification probe at a checkpoint (read-only).

Tests the two candidate mechanisms of the run-1 explosion limit cycle directly on the
memory core, using REAL write inputs captured by replaying the ckpt interface:

  1. pre-L2Norm activation norms inside the memory MLP per layer per step -- if these drift
     small, the _l2_norm backward (1/||x||, and 1/||x||^2 through the write's second-order
     term) amplifies cotangents;
  2. ||dL/dh_t|| for an aux-like read at the end of a T-step write chain, as a function of
     chain depth T-t, contrasted between the checkpoint core and a fresh-init core on the
     SAME captured inputs -- exponential growth = recurrent gradient explosion, and the
     contrast shows whether training drifted the core into it.

Run on a free GPU:
    HOME=/iris/u/kewalk srun --overlap --jobid <job> bash cluster_v34/chain_probe.sh
"""
# ruff: noqa: I001, B023, UP031, N806
import pyarrow.parquet as pq  # noqa: F401
import torch  # noqa: F401

import dataclasses
import sys

import jax
import jax.numpy as jnp
import numpy as np

sys.path.insert(0, "/iris/u/kewalk/memory_project/openpi/scripts")
from v34_init_scale import build_init_model
from grad_probe_ckpt import load_ckpt_model

sys.path.insert(0, "/iris/u/kewalk/memory_project/openpi/cluster_v34")

import openpi.models.model as _model
import openpi.models.memory as _memory
import openpi.shared.nnx_utils as nnx_utils
import openpi.training.config as _config
import openpi.training.data_loader as _data_loader

BATCHES = 2


def forward_prenorm_norms(memory, fast_weights, k):
    """Replicates memory._forward, returning each hidden layer's PRE-_l2_norm ||x||_2."""
    x = _memory._l2_norm(k)  # noqa: SLF001
    norms = []
    layers = len(memory.config.dims) - 1
    for i in range(layers):
        x = x @ fast_weights[f"w{i}"] + fast_weights[f"b{i}"]
        if i < layers - 1:
            x = jax.nn.silu(x)
            norms.append(jnp.linalg.norm(x, axis=-1))
            x = _memory._l2_norm(x)  # noqa: SLF001
    return norms  # list of [n] per hidden layer (per token)


def main():
    config = _config.get_config("pi05_yam_mem_v34")
    config = dataclasses.replace(config, batch_size=4, num_workers=0)
    model = load_ckpt_model(config)
    model.eval()
    init_model = build_init_model(config)
    init_model.eval()

    interface_step = nnx_utils.module_jit(model.v32_memory_interface_step)
    write_step = nnx_utils.module_jit(model.memory.write)

    loader = _data_loader.create_data_loader(config, shuffle=True, num_batches=BATCHES)

    for batch_index, (obs, _actions) in enumerate(loader):
        b, t = obs.seq_step_mask.shape
        valid = np.asarray(obs.seq_step_mask)
        state = model.memory.init_state(b)
        h_steps = []  # captured write tokens per step
        print(f"\n######## batch {batch_index}: b={b} T={t} valid_steps={valid.sum(1).tolist()}")
        for step in range(t):
            if not valid[:, step].any():
                break
            obs_dict = {
                "image": {k: v[:, step] for k, v in obs.images.items()},
                "image_mask": {k: v[:, step] for k, v in obs.image_masks.items()},
                "state": obs.state[:, step],
                "tokenized_prompt": obs.tokenized_prompt[:, step],
                "tokenized_prompt_mask": obs.tokenized_prompt_mask[:, step],
                "token_state_mask": obs.token_state_mask[:, step],
            }
            out = interface_step(_model.Observation.from_dict(obs_dict), state)
            h = out["write_tokens"]
            h_steps.append(np.asarray(h, dtype=np.float32))
            state, aux = write_step(state, h)
            drift = jax.tree.map(
                lambda fw, m0: fw - jnp.broadcast_to(m0.value, fw.shape),
                state.fast_weights,
                dict(model.memory.m0),
            )
            drift_norm = float(jnp.max(_memory._tree_norm(drift)))  # noqa: SLF001
            if step % 8 == 0 or step == t - 1:
                k, _v = model.memory.project_kv(h)
                norms = jax.vmap(lambda fw, kk: forward_prenorm_norms(model.memory, fw, kk))(
                    state.fast_weights, k
                )
                mins = [float(jnp.min(n)) for n in norms]
                meds = [float(jnp.median(n)) for n in norms]
                print(
                    f"step {step:3d}: inner_grad={np.asarray(aux['grad_norm']).max():.3g} "
                    f"clip={np.asarray(aux['clip_factor']).min():.3g} "
                    f"surprise={np.asarray(aux['surprise']).max():.3g} "
                    f"drift_max={drift_norm:.3g} "
                    f"prenorm_min={['%.3g' % m for m in mins]} prenorm_med={['%.3g' % m for m in meds]}"
                )
        T = len(h_steps)
        h_arr = jnp.asarray(np.stack(h_steps, axis=0))  # [T, b, n, d]

        # -- chain VJP: aux-bank read after T chained writes, gradient wrt every h_t --------
        aux_queries = jnp.broadcast_to(model.memory_aux_queries.value[None], (b, 16, 512))
        rng = np.random.default_rng(0)
        cot = jnp.asarray(rng.standard_normal((b, 16, 2048)), dtype=jnp.float32)
        cot = cot / jnp.linalg.norm(cot)

        def chain_scalar(memory_mod):
            def f(h_all):
                def step_fn(st, h):
                    new_st, _ = memory_mod.write(st, h)
                    return new_st, None

                st, _ = jax.lax.scan(step_fn, memory_mod.init_state(b), h_all)
                read = memory_mod.read_key(st, aux_queries)
                return jnp.sum(read * cot)

            return f

        for label, mem in (("ckpt2750", model.memory), ("fresh-init", init_model.memory)):
            grads = jax.jit(jax.grad(chain_scalar(mem)))(h_arr)
            g = np.asarray(jnp.sqrt(jnp.sum(jnp.square(grads), axis=(1, 2, 3))))  # [T]
            print(f"\n-- chain backward ||dL/dh_t|| ({label}), T={T}:")
            for step in range(T):
                depth = T - step
                print(f"   t={step:3d} depth={depth:3d}  ||g||={g[step]:.4e}")
            with np.errstate(divide="ignore"):
                ratios = g[:-1] / np.maximum(g[1:], 1e-30)
            print(
                f"   per-step amplification (g_t/g_t+1): median {np.median(ratios):.3f} "
                f"max {np.max(ratios):.3f}  total g_first/g_last={g[0] / max(g[-1], 1e-30):.3e}"
            )

        # -- state-cotangent norms vs remaining depth (ckpt core): sizes the backward clip --
        snaps = {0: model.memory.init_state(b)}
        st = snaps[0]
        for step in range(T):
            st, _ = write_step(st, jnp.asarray(h_steps[step]))
            snaps[step + 1] = st

        for t0 in sorted({0, max(0, T - 20), max(0, T - 10), max(0, T - 5), T - 1}):

            def tail(fast, mom, _t0=t0):
                def step_fn(s, h):
                    ns, _ = model.memory.write(s, h)
                    return ns, None

                s, _ = jax.lax.scan(step_fn, _memory.MemoryState(fast, mom), h_arr[_t0:])
                read = model.memory.read_key(s, aux_queries)
                return jnp.sum(read * cot)

            g_fast, g_mom = jax.jit(jax.grad(tail, argnums=(0, 1)))(snaps[t0].fast_weights, snaps[t0].momentum)
            n_fast = float(jnp.max(_memory._tree_norm(g_fast)))  # noqa: SLF001
            n_mom = float(jnp.max(_memory._tree_norm(g_mom)))  # noqa: SLF001
            print(f"   state-cotangent t={t0:3d} remaining_depth={T - t0:3d}: ||d/dM||={n_fast:.3e} ||d/dS||={n_mom:.3e}")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
