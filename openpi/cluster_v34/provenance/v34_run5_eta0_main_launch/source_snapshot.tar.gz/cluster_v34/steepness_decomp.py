"""WHY does the inner write gradient grow 20x during training? Decompose it.

The inner gradient of the associative loss is g = (2/n) J^T (M(k) - v), so ||g|| grows either
because the RESIDUAL r = M(k)-v grows (memory fits worse) or because the JACOBIAN J of the
memory MLP w.r.t. its own fast weights grows (memory has more gain). Those imply opposite
fixes, and the backward amplification through a clipped write scales like ||J||/||r||.

Hypothesis under test: J grows because the memory MLP's OUTPUT layer w3 is zero-init by
design (so a fresh memory reads exactly zero) and must grow for the memory to work at all;
every earlier layer's Jacobian is proportional to w3, so the inner gradient scales with it,
saturates the per-write clip, and inflates the backward.

Compares a fresh init against a checkpoint on IDENTICAL replayed real frames.
"""
# ruff: noqa: I001, B023, N806, UP031
import pyarrow.parquet as pq  # noqa: F401
import torch  # noqa: F401

import argparse
import dataclasses
import sys

import flax.nnx as nnx
import flax.traverse_util as traverse_util
import jax.numpy as jnp
import numpy as np

sys.path.insert(0, "/iris/u/kewalk/memory_project/openpi/scripts")
from v34_init_scale import build_init_model

import openpi.models.model as _model
import openpi.shared.nnx_utils as nnx_utils
import openpi.training.config as _config
import openpi.training.data_loader as _data_loader


def load_ckpt(config, ckpt, *, bf16_tower=True):
    model = build_init_model(config, bf16_tower=bf16_tower)
    graphdef, state = nnx.split(model)
    loaded = _model.restore_params(ckpt, restore_type=np.ndarray)
    flat = {}
    for key, value in traverse_util.flatten_dict(loaded, sep="/").items():
        if value is None:
            continue
        dtype = jnp.bfloat16 if (bf16_tower and key.startswith("PaliGemma/") and value.dtype == np.float32) else None
        flat[key] = jnp.asarray(value, dtype=dtype) if dtype else jnp.asarray(value)
    state.replace_by_pure_dict(traverse_util.unflatten_dict(flat, sep="/"))
    return nnx.merge(graphdef, state)


def m0_report(model, label):
    print(f"\n== m0 fast-weight INIT norms [{label}]")
    for name in sorted(model.memory.m0):
        arr = np.asarray(model.memory.m0[name].value, dtype=np.float64)
        print(f"   {name:>3}: shape={arr.shape!s:>13} norm={np.linalg.norm(arr):9.4f} max|x|={np.abs(arr).max():.4f}")
    for name in ("w_k", "w_v", "w_q"):
        arr = np.asarray(getattr(model.memory, name).kernel.value, dtype=np.float64)
        print(f"   {name:>3}: norm={np.linalg.norm(arr):9.4f}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", default="/iris/u/kewalk/memory_project/openpi/checkpoints/pi05_yam_mem_v34/v34_run3/1250/params")
    ap.add_argument("--batches", type=int, default=2)
    args = ap.parse_args()

    config = _config.get_config("pi05_yam_mem_v34")
    config = dataclasses.replace(config, batch_size=2, num_workers=0)

    models = {"init": build_init_model(config, bf16_tower=True), "ckpt": load_ckpt(config, args.ckpt)}
    for label, m in models.items():
        m.eval()
        m0_report(m, label)

    loader = _data_loader.create_data_loader(config, shuffle=True, num_batches=args.batches)
    steps = {label: nnx_utils.module_jit(m.v32_memory_interface_step) for label, m in models.items()}
    writes = {label: nnx_utils.module_jit(m.memory.write) for label, m in models.items()}

    for batch_index, (obs, _actions) in enumerate(loader):
        b, t = obs.seq_step_mask.shape
        valid = np.asarray(obs.seq_step_mask)
        print(f"\n######## batch {batch_index}  b={b} T={t}")
        for label, model in models.items():
            state = model.memory.init_state(b)
            print(f"-- [{label}]  step | residual_rms | inner_grad | clip | grad/resid (~||J||)")
            for step in range(t):
                if not valid[:, step].any():
                    break
                obs_dict = {
                    "image": {k: v[:, step] for k, v in obs.images.items()},
                    "image_mask": {k: v[:, step] for k, v in obs.image_masks.items()},
                    "state": obs.state[:, step],
                    "tokenized_prompt": obs.tokenized_prompt[:, step],
                    "tokenized_prompt_mask": obs.tokenized_prompt_mask[:, step],
                    "token_state_mask": obs.token_state_mask[:, step],
                }
                out = steps[label](_model.Observation.from_dict(obs_dict), state)
                h = out["write_tokens"]
                state, aux = writes[label](state, h)
                if step % 6 == 0 or step == t - 1:
                    resid = float(np.sqrt(np.asarray(aux["surprise"]).max()))
                    gnorm = float(np.asarray(aux["grad_norm"]).max())
                    clip = float(np.asarray(aux["clip_factor"]).min())
                    print(f"   {step:>4} | {resid:12.4f} | {gnorm:10.3f} | {clip:6.4f} | {gnorm / max(resid, 1e-9):10.3f}")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
