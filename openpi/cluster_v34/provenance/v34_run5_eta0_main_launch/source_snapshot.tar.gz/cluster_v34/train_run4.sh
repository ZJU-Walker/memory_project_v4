#!/bin/bash
# Definitive v34_run4: fresh official pi05 base, blank per-episode output seed, otherwise v34-identical.
set -euo pipefail
set -x

cd /iris/u/kewalk/memory_project/openpi
export HF_HOME=/iris/u/kewalk/.cache/huggingface
export OPENPI_DATA_HOME=/iris/u/kewalk/.cache/openpi
export OPENPI_JAX_CACHE_DIR=/iris/u/kewalk/.cache/jax
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.92

exec .venv/bin/python scripts/train.py pi05_yam_mem_v34_run4 \
  --exp-name v34_run4 \
  "$@" \
  --num-train-steps 20000 \
  --log-interval 100 \
  --save-interval 250 \
  --keep-period 5000 \
  --batch-size 12 \
  --gradient-accumulation-steps 1 \
  --fsdp-devices 4 \
  --seed 42
