#!/bin/bash
# v3.4 smoke run (plan 9 step 4): ~120 real optimizer steps on all 4 H100s, wandb off.
# Checks: FSDP-4 compile + memory fit, throughput, CE/flow sane, aux head moving, ladder
# probes training with zero main-model coupling, tanh(w) still ~0.
set -x
cd /iris/u/kewalk/memory_project/openpi || exit 1
export HOME=/iris/u/kewalk
export HF_HOME=/iris/u/kewalk/.cache/huggingface
export OPENPI_DATA_HOME=/iris/u/kewalk/.cache/openpi
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.92
exec .venv/bin/python scripts/train.py pi05_yam_mem_v34 \
  --exp-name v34_smoke \
  --overwrite \
  --no-wandb-enabled \
  --num-train-steps 120 \
  --log-interval 10 \
  --save-interval 100 \
  --batch-size 12 \
  --fsdp-devices 4 \
  --seed 42
