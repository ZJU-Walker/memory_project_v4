#!/bin/bash
set -x
cd /iris/u/kewalk/memory_project/openpi || exit 1
export HOME=/iris/u/kewalk
export HF_HOME=/iris/u/kewalk/.cache/huggingface
export OPENPI_DATA_HOME=/iris/u/kewalk/.cache/openpi
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.90
export CUDA_VISIBLE_DEVICES=0
exec .venv/bin/python cluster_v34/steepness_decomp.py "$@"
