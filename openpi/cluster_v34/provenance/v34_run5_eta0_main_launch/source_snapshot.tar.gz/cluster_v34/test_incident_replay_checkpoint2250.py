"""Focused invariants for the read-only incident replay helpers."""

# ruff: noqa: SLF001 - tests intentionally inspect diagnostic-only helper internals.

import importlib.util
import pathlib
from types import SimpleNamespace

import flax.nnx as nnx
import jax
import jax.numpy as jnp
import numpy as np
import pytest

from openpi.models.memory import MemoryConfig
from openpi.models.memory import TitansMemory

_SCRIPT = pathlib.Path(__file__).with_name("incident_replay_checkpoint2250.py")
_SPEC = importlib.util.spec_from_file_location("incident_replay_checkpoint2250", _SCRIPT)
assert _SPEC is not None
assert _SPEC.loader is not None
_MODULE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_MODULE)


def _tiny_memory() -> TitansMemory:
    return TitansMemory(
        MemoryConfig(
            d_input=3,
            d_key=2,
            hidden_dims=(3,),
            d_value=2,
            mlp_l2norm=True,
            blank_initial_output=True,
        ),
        rngs=nnx.Rngs(0),
    )


def test_invalid_rows_are_exact_state_noops():
    memory = _tiny_memory()
    old = memory.init_state(2)
    candidate = jax.tree.map(lambda x: x + 1, old)
    selected = _MODULE.apply_valid_state(candidate, old, jnp.array([True, False]))
    for name in old.fast_weights:
        np.testing.assert_array_equal(selected.fast_weights[name][1], old.fast_weights[name][1])
        np.testing.assert_array_equal(selected.momentum[name][1], old.momentum[name][1])
    assert any(
        not np.array_equal(np.asarray(selected.fast_weights[name][0]), np.asarray(old.fast_weights[name][0]))
        for name in old.fast_weights
    )
    assert _MODULE._state_max_abs_diff(old, old) == 0.0
    assert _MODULE._state_max_abs_diff(candidate, old) == 1.0


def test_output_only_preserves_nonoutput_fast_and_momentum_bits():
    memory = _tiny_memory()
    old = memory.init_state(2)
    key = jnp.ones((2, 2, 2), dtype=jnp.float32)
    value = jnp.ones((2, 2, 2), dtype=jnp.float32)
    new, _aux = _MODULE.output_only_write_kv(
        memory,
        old,
        key,
        value,
        jnp.full((2,), 0.1),
        jnp.full((2,), 0.9),
        jnp.full((2,), 0.01),
    )
    for name in ("w0", "b0"):
        np.testing.assert_array_equal(new.fast_weights[name], old.fast_weights[name])
        np.testing.assert_array_equal(new.momentum[name], old.momentum[name])
    assert not np.array_equal(np.asarray(new.fast_weights["w1"]), np.asarray(old.fast_weights["w1"]))


def test_output_only_clip_uses_output_leaf_norm():
    memory = _tiny_memory()
    old = memory.init_state(2)
    key = jnp.ones((2, 2, 2), dtype=jnp.float32)
    value = jnp.ones((2, 2, 2), dtype=jnp.float32)
    surprise, _grads, leaf_norms, full_norm = _MODULE._raw_write_gradients(memory, old, key, value)
    del surprise, full_norm
    output_norm = jnp.sqrt(jnp.square(leaf_norms["w1"]) + jnp.square(leaf_norms["b1"]))
    _new, aux = _MODULE.output_only_write_kv(
        memory, old, key, value, jnp.full((2,), 0.1), jnp.full((2,), 0.9), jnp.full((2,), 0.01)
    )
    expected = jnp.minimum(1.0, memory.config.max_grad_norm / (output_norm + 1e-12))
    np.testing.assert_allclose(aux["clip_factor"], expected, rtol=1e-6)


def test_eta_zero_removes_old_output_momentum_but_eta_configured_retains_it():
    memory = _tiny_memory()
    fresh = memory.init_state(2)
    old = _MODULE._memory.MemoryState(
        fast_weights=fresh.fast_weights,
        momentum={
            name: (jnp.ones_like(value) if name == "w1" else value)
            for name, value in fresh.momentum.items()
        },
    )
    key = jnp.ones((2, 2, 2), dtype=jnp.float32)
    value = jnp.ones((2, 2, 2), dtype=jnp.float32)
    theta = jnp.full((2,), 0.1)
    alpha = jnp.full((2,), 0.01)
    zero, _ = _MODULE.output_only_write_kv(memory, old, key, value, theta, jnp.zeros((2,)), alpha)
    configured, _ = _MODULE.output_only_write_kv(memory, old, key, value, theta, jnp.full((2,), 0.9), alpha)
    np.testing.assert_allclose(
        configured.momentum["w1"] - zero.momentum["w1"],
        old.momentum["w1"] * 0.9,
        rtol=1e-5,
    )
    np.testing.assert_array_equal(zero.momentum["w0"], old.momentum["w0"])


def test_blank_output_init_and_padding_metrics_are_explicit():
    memory = _tiny_memory()
    state = memory.init_state(1)
    np.testing.assert_array_equal(state.fast_weights["w1"], 0.0)
    np.testing.assert_array_equal(state.fast_weights["b1"], 0.0)
    assert _MODULE._row_metric(jnp.array([jnp.nan]), sample=0, valid=False, name="padding") is None
    try:
        _MODULE._row_metric(jnp.array([jnp.nan]), sample=0, valid=True, name="bad")
    except FloatingPointError:
        pass
    else:
        raise AssertionError("valid non-finite telemetry must fail closed")


def test_parameter_source_paths_and_raw_transform_are_explicit():
    checkpoint = pathlib.Path("/run/2250/params")
    assert _MODULE._parameter_restore_path(checkpoint, "ema") == checkpoint
    assert _MODULE._parameter_restore_path(checkpoint, "raw") == checkpoint.parent / "train_state"
    transforms = _MODULE._raw_parameter_transforms()
    assert set(transforms) == {r"params/(.*)"}
    assert transforms[r"params/(.*)"].original_key == r"params/\1/value"


def test_interface_jit_preserves_observation_then_state_argument_order(monkeypatch):
    model = object()
    graphdef = object()
    model_state = object()
    frozen_model = object()
    observation = object()
    memory_state = object()
    segment_masked = object()
    expected = {"key": object()}

    monkeypatch.setattr(_MODULE.nnx, "split", lambda value: (graphdef, model_state))

    def fake_merge(actual_graphdef, actual_state):
        assert actual_graphdef is graphdef
        assert actual_state is model_state
        return frozen_model

    def fake_interface(actual_model, actual_observation, actual_state, actual_mask):
        assert actual_model is frozen_model
        assert actual_observation is observation
        assert actual_state is memory_state
        assert actual_mask is segment_masked
        return expected

    monkeypatch.setattr(_MODULE.nnx, "merge", fake_merge)
    monkeypatch.setattr(_MODULE.jax, "jit", lambda function: function)
    monkeypatch.setattr(_MODULE, "_masked_interface_step", fake_interface)

    interface, returned_model_state = _MODULE._make_interface_jit(model)
    assert returned_model_state is model_state
    assert interface(model_state, observation, memory_state, segment_masked) is expected


def test_jitted_model_and_memory_parameters_are_dynamic_operands(monkeypatch):
    class TinyInterface(nnx.Module):
        def __init__(self):
            self.scale = nnx.Param(jnp.array(2.0))

    interface_model = TinyInterface()
    monkeypatch.setattr(
        _MODULE,
        "_masked_interface_step",
        lambda model, observation, state, segment_masked: model.scale.value * observation + state + segment_masked,
    )
    interface, model_state = _MODULE._make_interface_jit(interface_model)
    interface_jaxpr = jax.make_jaxpr(interface)(model_state, jnp.array(3.0), jnp.array(4.0), jnp.array(5.0))
    assert not interface_jaxpr.consts
    assert not interface_jaxpr.jaxpr.constvars
    np.testing.assert_allclose(interface(model_state, 3.0, 4.0, 5.0), 15.0)

    memory = _tiny_memory()
    model = SimpleNamespace(memory=memory)
    full, output_only, memory_params = _MODULE._make_core_fns(model)
    state = memory.init_state(1)
    key = jnp.ones((1, 2, 2), dtype=jnp.float32)
    value = jnp.ones((1, 2, 2), dtype=jnp.float32)
    gate = jnp.ones((1,), dtype=jnp.float32) * 0.1
    core_jaxpr = jax.make_jaxpr(full)(memory_params, state, key, value, gate, gate, gate)
    assert not core_jaxpr.consts
    assert not core_jaxpr.jaxpr.constvars
    _next_state, _aux, full_stats = full(memory_params, state, key, value, gate, gate, gate)
    assert len(full_stats) == 4
    _next_state, _aux, stats = output_only(memory_params, state, key, value, gate, gate, gate)
    assert len(stats) == 4
    surprise, leaf_norms, full_norm, effective_norm = stats
    assert surprise.shape == full_norm.shape == effective_norm.shape == (1,)
    assert set(leaf_norms) == set(state.fast_weights)


def test_momentum_reset_arm_keeps_nonzero_invalid_row_momentum_until_next_valid_step():
    memory = _tiny_memory()
    model = SimpleNamespace(memory=memory, memory_state_mask_prob=0.0)
    observation = _MODULE._model.Observation(
        images={},
        image_masks={},
        state=jnp.zeros((2, 3, 1), dtype=jnp.float32),
        # Sample 1 is padded only at the middle position, then becomes valid again so its
        # retained pre-write momentum is observable in the emitted telemetry.
        seq_step_mask=jnp.array([[True, True, True], [True, False, True]]),
    )

    def interface(_model_state, frame, _state, _segment_masked):
        batch = frame.state.shape[0]
        return {
            "key": jnp.ones((batch, 1, 2), dtype=jnp.float32),
            "value": jnp.ones((batch, 1, 2), dtype=jnp.float32),
            "theta": jnp.full((batch,), 0.1),
            "eta": jnp.full((batch,), 0.9),
            "alpha": jnp.full((batch,), 0.01),
        }

    def core(_params, state, _key, _value, theta, eta, alpha):
        candidate = _MODULE._memory.MemoryState(
            fast_weights=state.fast_weights,
            momentum=jax.tree.map(lambda value: value + 1.0, state.momentum),
        )
        batch = theta.shape[0]
        zeros = jnp.zeros((batch,), dtype=jnp.float32)
        leaf_norms = dict.fromkeys(state.fast_weights, zeros)
        aux = {"clip_factor": zeros, "theta": theta, "eta": eta, "alpha": alpha}
        return candidate, aux, (zeros, leaf_norms, zeros, zeros)

    rows = _MODULE._run_batch(
        0,
        observation,
        model,
        interface,
        object(),
        core,
        core,
        object(),
        include_momentum_reset=True,
    )
    resumed = next(
        row
        for row in rows
        if row["arm"] == "output_only_configured_eta_per_write_momentum_reset"
        and row["sample"] == 1
        and row["position"] == 2
    )
    assert resumed["prewrite_momentum_norm"] > 0.0


def test_jsonl_preflight_rejects_checkpoint_paths_and_missing_or_unwritable_parents(tmp_path, monkeypatch):
    step = tmp_path / "2250"
    checkpoint = step / "params"
    checkpoint.mkdir(parents=True)
    with pytest.raises(ValueError, match="outside the selected checkpoint step"):
        _MODULE._preflight_jsonl(step / "diagnostics.jsonl", checkpoint)
    with pytest.raises(FileNotFoundError, match="parent directory does not exist"):
        _MODULE._preflight_jsonl(tmp_path / "missing" / "diagnostics.jsonl", checkpoint)

    destination = tmp_path / "diagnostics.jsonl"
    assert _MODULE._preflight_jsonl(destination, checkpoint) == destination.resolve()

    def deny_creation(*_args, **_kwargs):
        raise OSError("permission denied")

    monkeypatch.setattr(_MODULE.tempfile, "mkstemp", deny_creation)
    with pytest.raises(PermissionError, match="parent is not writable"):
        _MODULE._preflight_jsonl(destination, checkpoint)


def test_main_preflights_jsonl_before_config_or_model_construction(tmp_path, monkeypatch):
    step = tmp_path / "2250"
    checkpoint = step / "params"
    checkpoint.mkdir(parents=True)
    (step / "train_state").mkdir()
    monkeypatch.setattr(
        _MODULE._config,
        "get_config",
        lambda _name: pytest.fail("config/model work must not start before JSONL preflight"),
    )
    with pytest.raises(ValueError, match="outside the selected checkpoint step"):
        _MODULE.main(["--checkpoint", str(checkpoint), "--jsonl", str(step / "diagnostics.jsonl")])


def test_jsonl_emit_is_atomic_and_preserves_existing_destination_on_failure(tmp_path, monkeypatch):
    destination = tmp_path / "diagnostics.jsonl"
    destination.write_text("original\n", encoding="utf-8")
    with pytest.raises(TypeError):
        _MODULE._emit_rows([{"not_json": object()}], destination)
    assert destination.read_text(encoding="utf-8") == "original\n"
    assert list(tmp_path.glob(f".{destination.name}.*.tmp")) == []

    replacements = []
    real_replace = _MODULE.os.replace

    def record_replace(source, target):
        replacements.append((pathlib.Path(source), pathlib.Path(target)))
        real_replace(source, target)

    monkeypatch.setattr(_MODULE.os, "replace", record_replace)
    _MODULE._emit_rows([{"value": 1}], destination)
    assert destination.read_text(encoding="utf-8") == '{"value": 1}\n'
    assert replacements[0][0].parent == destination.parent
    assert replacements[0][1] == destination


def test_run4_replay_config_assertions_fail_closed_on_critical_fields():
    config = _MODULE._config.get_config(_MODULE.CONFIG_NAME)
    _MODULE._assert_pinned_run4_config(config)
    critical_mutations = (
        ("blank_initial_output", False),
        ("mlp_l2norm", False),
        ("max_grad_norm", 2.0),
        ("theta_bias", -1.0),
        ("eta_bias", 1.0),
        ("alpha_bias", -3.0),
    )
    for field, value in critical_mutations:
        changed_memory = _MODULE.dataclasses.replace(config.model.memory, **{field: value})
        changed_model = _MODULE.dataclasses.replace(config.model, memory=changed_memory)
        changed = _MODULE.dataclasses.replace(config, model=changed_model)
        with pytest.raises(ValueError, match=f"model.memory.{field}"):
            _MODULE._assert_pinned_run4_config(changed)

    for field, changes in (
        (
            "memory_task_conditioned_write",
            {"memory_task_conditioned_write": False, "memory_conditioner_context": "instruction_state"},
        ),
        ("memory_conditioner_context", {"memory_conditioner_context": "instruction_state"}),
        ("memory_state_mask_prob", {"memory_state_mask_prob": 0.0}),
        ("memory_state_mask_dual_view", {"memory_state_mask_dual_view": True}),
        ("memory_qk_norm", {"memory_qk_norm": False}),
        ("memory_letterbox_source_hw", {"memory_letterbox_source_hw": None}),
    ):
        changed_model = _MODULE.dataclasses.replace(config.model, **changes)
        changed = _MODULE.dataclasses.replace(config, model=changed_model)
        with pytest.raises(ValueError, match=f"model.{field}"):
            _MODULE._assert_pinned_run4_config(changed)


def test_long_horizon_conflicting_writes_remain_finite_and_momentum_bounded():
    memory = _tiny_memory()
    key = jnp.array([[[1.0, 0.0], [0.999, 0.001]]], dtype=jnp.float32)
    value_a = jnp.array([[[1.0, 0.0], [1.0, 0.0]]], dtype=jnp.float32)
    value_b = -value_a
    theta = jnp.array([0.1], dtype=jnp.float32)
    alpha = jnp.array([0.01], dtype=jnp.float32)

    for output_only in (False, True):
        for eta_value in (0.0, 0.9):
            state = memory.init_state(1)
            initial = state
            eta = jnp.array([eta_value], dtype=jnp.float32)
            if output_only:
                step = jax.jit(
                    lambda current, target, eta_gate=eta: _MODULE.output_only_write_kv(
                        memory, current, key, target, theta, eta_gate, alpha
                    )[0]
                )
            else:
                step = jax.jit(
                    lambda current, target, eta_gate=eta: memory.write_kv(
                        current, key, target, theta, eta_gate, alpha
                    )[0]
                )
            for position in range(128):
                state = step(state, value_a if position % 2 == 0 else value_b)

            for leaf in jax.tree.leaves(state):
                assert np.isfinite(np.asarray(leaf)).all()
            momentum_norm = float(
                np.sqrt(
                    sum(
                        np.sum(np.square(np.asarray(leaf, dtype=np.float64)))
                        for leaf in state.momentum.values()
                    )
                )
            )
            theoretical_bound = 0.1 if eta_value == 0.0 else 0.1 / (1.0 - eta_value)
            assert momentum_norm <= theoretical_bound + 1e-4
            if output_only:
                for name in ("w0", "b0"):
                    np.testing.assert_array_equal(state.fast_weights[name], initial.fast_weights[name])
                    np.testing.assert_array_equal(state.momentum[name], initial.momentum[name])
