#!/usr/bin/env python3
"""Read-only Slurm/log watcher for an offline diagnostic job.

Unlike the training watcher, this process never calls ``scancel``.  It records scheduler state
transitions and newly observed fatal-looking log lines, then exits after Slurm reports a terminal
state.  It is safe to leave on the login host while a GPU diagnostic is pending.
"""

from __future__ import annotations

import argparse
import pathlib
import re
import subprocess
import time

_JOB_ID = re.compile(r"^\d+$")
_STEP_ID = re.compile(r"^\d+\.\d+$")
_TERMINAL = {"BOOT_FAIL", "CANCELLED", "COMPLETED", "DEADLINE", "FAILED", "NODE_FAIL", "OUT_OF_MEMORY", "PREEMPTED", "TIMEOUT"}
_ALERT = re.compile(r"(?:Traceback|OutOfMemory|OUT_OF_MEMORY|CUDA error|NCCL|\bNaN\b|\bInf\b|FloatingPointError|AssertionError)", re.IGNORECASE)


def _run(*args: str) -> str:
    result = subprocess.run(args, check=False, capture_output=True, text=True)
    return result.stdout.strip()


def _canonical_state(value: str) -> str:
    """Normalize Slurm annotations such as ``CANCELLED by <uid>`` and ``FAILED+``."""
    base = value.strip().split("+", maxsplit=1)[0]
    return base.split(maxsplit=1)[0].upper() if base else "UNKNOWN"


def _step_accounting_state(step_id: str) -> tuple[str, str]:
    """Read the terminal state of one exact Slurm step, falling back to full accounting."""
    for allocations_only in (True, False):
        command = ["sacct"]
        if allocations_only:
            command.append("-X")
        command.extend(
            [
                "--noheader",
                "--parsable2",
                "--jobs",
                step_id,
                "--format=JobID,State,ExitCode",
            ]
        )
        accounting = _run(*command)
        for row in accounting.splitlines():
            fields = row.split("|")
            if len(fields) < 3 or fields[0].strip() != step_id:
                continue
            return _canonical_state(fields[1]), f"ExitCode={fields[2].strip()}"
    return "UNKNOWN", "absent from squeue and sacct"


def _step_scheduler_state(step_id: str) -> tuple[str, str]:
    parent_id, _ = step_id.split(".", maxsplit=1)
    # This cluster's Slurm 25.11 step view supports the step id (`%i`) but rejects the
    # job-state/reason format codes (`%T`, `%t`, and `%R`).  Presence in `squeue --steps`
    # is sufficient to establish that the exact step is active; once it disappears, sacct
    # supplies its terminal state and exit code.
    queued = _run(
        "squeue",
        "--noheader",
        "--steps",
        "--jobs",
        parent_id,
        "--format=%i",
    )
    for row in queued.splitlines():
        if row.strip() == step_id:
            return "RUNNING", "present in squeue --steps"
    return _step_accounting_state(step_id)


def _scheduler_state(job_id: str) -> tuple[str, str]:
    if _STEP_ID.fullmatch(job_id):
        return _step_scheduler_state(job_id)
    queued = _run("squeue", "--noheader", "--jobs", job_id, "--format=%T|%R")
    if queued:
        state, _, reason = queued.splitlines()[0].partition("|")
        return state.strip().upper(), reason.strip()
    accounting = _run("sacct", "-X", "--noheader", "--parsable2", "--jobs", job_id, "--format=State,ExitCode")
    if not accounting:
        return "UNKNOWN", "absent from squeue and sacct"
    state, _, exit_code = accounting.splitlines()[0].partition("|")
    return _canonical_state(state), f"ExitCode={exit_code.strip()}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--job-id", required=True)
    parser.add_argument("--audit-log", type=pathlib.Path, required=True)
    parser.add_argument("--stdout", type=pathlib.Path, required=True)
    parser.add_argument("--stderr", type=pathlib.Path, required=True)
    parser.add_argument("--poll-seconds", type=float, default=60.0)
    parser.add_argument("--heartbeat-seconds", type=float, default=1800.0)
    args = parser.parse_args()
    if not (_JOB_ID.fullmatch(args.job_id) or _STEP_ID.fullmatch(args.job_id)):
        raise ValueError(f"refusing non-numeric diagnostic job or step id: {args.job_id!r}")
    if not 10.0 <= args.poll_seconds <= 300.0:
        raise ValueError("poll-seconds must be between 10 and 300")
    args.audit_log.parent.mkdir(parents=True, exist_ok=True)

    def emit(message: str) -> None:
        line = f"{time.strftime('%Y-%m-%dT%H:%M:%S%z')} {message}"
        print(line, flush=True)
        with args.audit_log.open("a", encoding="utf-8") as stream:
            stream.write(line + "\n")

    emit(f"diagnostic watcher started job={args.job_id}")
    offsets = {args.stdout: 0, args.stderr: 0}
    last_state: tuple[str, str] | None = None
    last_heartbeat = 0.0
    while True:
        current = _scheduler_state(args.job_id)
        now = time.monotonic()
        if current != last_state or now - last_heartbeat >= args.heartbeat_seconds:
            emit(f"scheduler state={current[0]} reason={current[1]!r}")
            last_state = current
            last_heartbeat = now

        for path, offset in offsets.items():
            if not path.exists():
                continue
            with path.open(encoding="utf-8", errors="replace") as stream:
                stream.seek(offset)
                lines = stream.readlines()
                offsets[path] = stream.tell()
            for line in lines:
                if _ALERT.search(line):
                    emit(f"alert file={path.name} line={line.strip()[:1000]!r}")

        if current[0] in _TERMINAL:
            emit(f"diagnostic watcher exiting terminal_state={current[0]} {current[1]}")
            return 0 if current[0] == "COMPLETED" else 2
        time.sleep(args.poll_seconds)


if __name__ == "__main__":
    raise SystemExit(main())
