"""Read-only v34_run4 checkpoint-2250 memory-core replay.

This is deliberately an offline diagnostic.  By default it restores raw model parameters from
the sibling ``train_state``; ``--parameter-source ema`` selects the EMA ``params`` tree.  It
puts the model in eval mode and never creates or modifies a checkpoint.  The expensive model-side
early interface is run once per valid/padded position.  Its projected K/V and gates are then
replayed through four memory-core arms:

* full plasticity, configured eta;
* full plasticity, eta=0;
* output-only plasticity, configured eta;
* output-only plasticity, eta=0.

The output-only arm uses the production associative loss, gradient clipping, momentum and
forgetting equations for ``w3``/``b3`` only.  All non-output fast weights and momentum are
returned by identity, so their normal forgetting path is intentionally disabled.  This makes
it a retention control rather than an approximation to the full write.

Example (GPU; no checkpoint/model files are written; ``--jsonl`` is an optional diagnostics log):

    UV_CACHE_DIR=/tmp/openpi-uv-cache uv run python cluster_v34/incident_replay_checkpoint2250.py \
        --batches 2 --batch-size 2

The default ``.../2250/params`` path identifies the EMA checkpoint item; the default ``raw``
source resolves its sibling ``.../2250/train_state`` and selects only top-level ``params``.
Both source and path are labelled in the output.
"""

# ruff: noqa: E402, I001 - path setup and pyarrow/torch precede openpi, matching loader scripts.
import argparse
import dataclasses
import json
import os
import pathlib
import sys
import tempfile
from collections import defaultdict
from typing import Any

import jax
import jax.numpy as jnp
import numpy as np
import orbax.checkpoint as ocp
import pyarrow.parquet as pq  # noqa: F401
import torch  # noqa: F401

_REPO_ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_REPO_ROOT / "src"))
sys.path.insert(0, str(_REPO_ROOT / "scripts"))

import flax.nnx as nnx
import flax.traverse_util as traverse_util

import openpi.models.model as _model
import openpi.models.memory as _memory
import openpi.training.config as _config
import openpi.training.data_loader as _data_loader
from v34_init_scale import build_init_model

DEFAULT_CHECKPOINT = _REPO_ROOT / "checkpoints/pi05_yam_mem_v34_run4/v34_run4/2250/params"
CONFIG_NAME = "pi05_yam_mem_v34_run4"
OUTPUT_LEAF_NAMES = ("w3", "b3")


def _tree_norms(tree: dict[str, jax.Array]) -> dict[str, jax.Array]:
    """Per-sample L2 norms for a [batch, ...] tree."""
    return {
        name: jnp.sqrt(jnp.sum(jnp.square(value), axis=tuple(range(1, value.ndim))))
        for name, value in tree.items()
    }


def _raw_write_gradients(
    memory: _memory.TitansMemory,
    state: _memory.MemoryState,
    k: jax.Array,
    v: jax.Array,
) -> tuple[jax.Array, dict[str, jax.Array], dict[str, jax.Array], jax.Array]:
    """Return production write surprise and *pre-clip* per-leaf gradients.

    This is the same frame-mean associative objective used by ``TitansMemory.write_kv``.  It
    intentionally calls the memory's private forward implementation rather than reimplementing
    the MLP, so ``mlp_l2norm`` and future core changes remain diagnostic-visible.
    """

    k = k.astype(jnp.float32)
    v = v.astype(jnp.float32)

    def loss(fast_weights, key, value):
        return jnp.mean(jnp.sum(jnp.square(memory._forward(fast_weights, key) - value), axis=-1))  # noqa: SLF001

    surprise, grads = jax.vmap(jax.value_and_grad(loss))(state.fast_weights, k, v)
    leaf_norms = _tree_norms(grads)
    global_norm = jnp.sqrt(sum(jnp.square(norm) for norm in leaf_norms.values()))
    return surprise, grads, leaf_norms, global_norm


def _output_only_write_kv_with_stats(
    memory: _memory.TitansMemory,
    state: _memory.MemoryState,
    k: jax.Array,
    v: jax.Array,
    theta: jax.Array,
    eta: jax.Array,
    alpha: jax.Array,
) -> tuple[
    _memory.MemoryState,
    dict[str, jax.Array],
    tuple[jax.Array, dict[str, jax.Array], jax.Array, jax.Array],
]:
    """Production ``write_kv`` with plasticity restricted to the output layer.

    ``w3`` and ``b3`` follow the regular momentum/forgetting update.  Every other fast-weight
    and momentum leaf is returned unchanged, bit-for-bit: no gradient and no forgetting are
    applied to those leaves.  Clipping uses the raw norm of the retained output update; the
    full-tree raw norm is still logged for comparison with full plasticity.
    """

    surprise, grads, _leaf_norms, grad_norm = _raw_write_gradients(memory, state, k, v)
    output_names = {f"w{memory._num_layers - 1}", f"b{memory._num_layers - 1}"}  # noqa: SLF001
    output_grad_norm = jnp.sqrt(
        sum(jnp.square(norm) for name, norm in _leaf_norms.items() if name in output_names)
    )
    # The output arm has no non-output update.  Its clip therefore uses the raw norm of the
    # update that remains, while ``grad_norm`` below still reports that effective norm.
    clip = jax.lax.stop_gradient(
        jnp.minimum(1.0, memory.config.max_grad_norm / (output_grad_norm + 1e-12))
    )
    clipped = {
        name: value * clip.reshape((clip.shape[0],) + (1,) * (value.ndim - 1))
        for name, value in grads.items()
    }
    fast_weights = {}
    momentum = {}
    for name, old_fast in state.fast_weights.items():
        if name not in output_names:
            # Do not use where/multiply here: returning the original array preserves exact bits.
            fast_weights[name] = old_fast
            momentum[name] = state.momentum[name]
            continue
        old_momentum = state.momentum[name]

        def broadcast(gate, leaf):
            return gate.reshape((gate.shape[0],) + (1,) * (leaf.ndim - 1))

        new_momentum = broadcast(eta, old_momentum) * old_momentum - broadcast(theta, clipped[name]) * clipped[name]
        momentum[name] = new_momentum
        fast_weights[name] = broadcast(1.0 - alpha, old_fast) * old_fast + new_momentum
    aux = {
        "surprise": surprise,
        "grad_norm": output_grad_norm,
        "clip_factor": clip,
        "theta": theta,
        "eta": eta,
        "alpha": alpha,
    }
    return _memory.MemoryState(fast_weights=fast_weights, momentum=momentum), aux, (
        surprise,
        _leaf_norms,
        grad_norm,
        output_grad_norm,
    )


def output_only_write_kv(
    memory: _memory.TitansMemory,
    state: _memory.MemoryState,
    k: jax.Array,
    v: jax.Array,
    theta: jax.Array,
    eta: jax.Array,
    alpha: jax.Array,
) -> tuple[_memory.MemoryState, dict[str, jax.Array]]:
    """Public two-return-value wrapper matching ``TitansMemory.write_kv``."""

    next_state, aux, _stats = _output_only_write_kv_with_stats(memory, state, k, v, theta, eta, alpha)
    return next_state, aux


def apply_valid_state(
    candidate: _memory.MemoryState, old: _memory.MemoryState, valid: jax.Array
) -> _memory.MemoryState:
    """Commit only valid rows; invalid rows are exact state no-ops."""

    def select(new, previous):
        mask = valid.reshape((valid.shape[0],) + (1,) * (new.ndim - 1))
        return jnp.where(mask, new, previous)

    return _memory.MemoryState(
        fast_weights=jax.tree.map(select, candidate.fast_weights, old.fast_weights),
        momentum=jax.tree.map(select, candidate.momentum, old.momentum),
    )


def _masked_interface_step(
    model: Any,
    observation: _model.Observation,
    memory_state: _memory.MemoryState,
    segment_masked: jax.Array | None,
) -> dict[str, jax.Array]:
    """Early interface matching training, including the input-level state null replacement."""

    preprocessed = _model.preprocess_observation(None, observation, train=False)
    prefix_tokens, prefix_mask, prefix_ar = model.embed_prefix(preprocessed)
    num_img = prefix_mask.shape[1] - model.max_token_len
    if segment_masked is not None:
        prefix_tokens = model._v32_apply_state_null(  # noqa: SLF001
            prefix_tokens,
            prefix_mask,
            preprocessed.token_state_mask,
            segment_masked,
        )
    prepared = model._v32_prepare_memory_interface(  # noqa: SLF001
        prefix_tokens,
        prefix_mask,
        prefix_ar,
        memory_state,
        top_token_count=num_img // len(preprocessed.images),
        state_token_mask=preprocessed.token_state_mask,
    )
    write_tokens = prepared["write_tokens"]
    key, value = model.memory.project_kv(write_tokens)
    theta, eta, alpha = model.memory.gates(write_tokens)
    return {
        "write_tokens": write_tokens,
        "key": key,
        "value": value,
        "theta": theta,
        "eta": eta,
        "alpha": alpha,
    }


def _make_interface_jit(model: Any):
    graphdef, model_state = nnx.split(model)

    def run(dynamic_model_state, observation, state, segment_masked):
        frozen_model = nnx.merge(graphdef, dynamic_model_state)
        return _masked_interface_step(frozen_model, observation, state, segment_masked)

    return jax.jit(run), model_state


def _parameter_restore_path(checkpoint: pathlib.Path, source: str) -> pathlib.Path:
    """Resolve EMA ``params`` or the sibling raw ``train_state`` item."""
    if source == "ema":
        return checkpoint
    if source == "raw":
        return checkpoint.parent / "train_state"
    raise ValueError(f"parameter source must be 'raw' or 'ema', got {source!r}")


def _raw_parameter_transforms() -> dict[str, ocp.RestoreTransform]:
    """Map target ``params/<leaf>`` to raw train-state ``params/<leaf>/value`` only.

    The transform is intentionally explicit about the top-level ``params`` subtree: optimizer
    state, EMA parameters, and the training step are never part of this restore request.
    """
    return {r"params/(.*)": ocp.RestoreTransform(original_key=r"params/\1/value")}


def _restore_raw_pure_params(source_path: pathlib.Path, target_params: dict[str, Any]) -> dict[str, Any]:
    """Restore a raw ``params`` subtree into an explicit pure-dict target."""
    item = {"params": target_params}
    restore_args = jax.tree.map(
        lambda value: ocp.ArrayRestoreArgs(restore_type=np.ndarray),
        item,
    )
    with ocp.PyTreeCheckpointer() as checkpointer:
        restored = checkpointer.restore(
            source_path,
            ocp.args.PyTreeRestore(
                item=item,
                restore_args=restore_args,
                transforms=_raw_parameter_transforms(),
                transforms_default_to_original=False,
            ),
        )
    loaded = restored["params"]
    # The target State supplies both structure and expected shapes.  Validate before any dtype
    # conversion so a mismatched raw train-state fails closed rather than silently grafting.
    def check_shape(actual, target):
        if np.shape(actual) != np.shape(target):
            raise ValueError(f"raw parameter shape mismatch: restored={np.shape(actual)} target={np.shape(target)}")
        return actual

    return jax.tree.map(check_shape, loaded, target_params)


def _restore_raw_params(checkpoint: pathlib.Path, target_state: nnx.State) -> dict[str, Any]:
    """Restore only raw model params from sibling ``train_state`` using an existing state target."""
    source_path = _parameter_restore_path(checkpoint, "raw")
    if not source_path.exists():
        raise FileNotFoundError(f"raw parameter source not found: {source_path}")
    return _restore_raw_pure_params(source_path, target_state.to_pure_dict())


def _make_core_fns(model: Any):
    graphdef, memory_params = nnx.split(model.memory)

    def full(dynamic_memory_params, state, key, value, theta, eta, alpha):
        memory = nnx.merge(graphdef, dynamic_memory_params)
        surprise, _grads, leaf_norms, global_norm = _raw_write_gradients(memory, state, key, value)
        next_state, aux = memory.write_kv(state, key, value, theta, eta, alpha)
        return next_state, aux, (surprise, leaf_norms, global_norm, global_norm)

    def output_only(dynamic_memory_params, state, key, value, theta, eta, alpha):
        memory = nnx.merge(graphdef, dynamic_memory_params)
        return _output_only_write_kv_with_stats(memory, state, key, value, theta, eta, alpha)

    return jax.jit(full), jax.jit(output_only), memory_params


def _frame_observation(observation: _model.Observation, position: int) -> _model.Observation:
    """Slice one sequence position without changing any values or masks."""

    def pick(x):
        return None if x is None else x[:, position]

    return _model.Observation(
        images={name: image[:, position] for name, image in observation.images.items()},
        image_masks={name: mask[:, position] for name, mask in observation.image_masks.items()},
        state=observation.state[:, position],
        tokenized_prompt=pick(observation.tokenized_prompt),
        tokenized_prompt_mask=pick(observation.tokenized_prompt_mask),
        token_state_mask=pick(observation.token_state_mask),
    )


def _phase(observation: _model.Observation, sample: int, position: int, *, valid: bool) -> str:
    if not valid:
        return "padding"
    evidence = observation.seq_evidence_mask
    waiting = observation.seq_waiting_mask
    if evidence is not None and bool(evidence[sample, position]):
        return "evidence"
    if waiting is not None and bool(waiting[sample, position]):
        return "waiting"
    return "other"


def _state_summary(state: _memory.MemoryState) -> tuple[dict[str, jax.Array], dict[str, jax.Array]]:
    fast = _tree_norms(state.fast_weights)
    momentum = _tree_norms(state.momentum)
    return fast, momentum


def _group_norm(norms: dict[str, float], names: set[str]) -> float:
    result = float(np.sqrt(sum(value * value for name, value in norms.items() if name in names)))
    if not np.isfinite(result):
        raise FloatingPointError("non-finite valid grouped state telemetry")
    return result


def _state_max_abs_diff(left: _memory.MemoryState, right: _memory.MemoryState) -> float:
    """Host scalar used to fail closed if the fixed-input baseline replay diverges."""
    leaves = jax.tree.leaves(
        jax.tree.map(lambda x, y: jnp.max(jnp.abs(x - y)), left, right)
    )
    return max(float(np.asarray(value)) for value in leaves)


def _row_metric(value: Any, *, sample: int, valid: bool, name: str) -> float | None:
    """Convert one scalar telemetry value, nulling padding and failing valid non-finites."""
    if not valid:
        return None
    scalar = float(np.asarray(value[sample] if np.asarray(value).ndim else value))
    if not np.isfinite(scalar):
        raise FloatingPointError(f"non-finite valid replay metric {name} at sample={sample}")
    return scalar


def _row_norm_dict(
    values: dict[str, Any], *, sample: int, valid: bool, prefix: str
) -> dict[str, float | None]:
    return {
        name: _row_metric(value, sample=sample, valid=valid, name=f"{prefix}.{name}")
        for name, value in values.items()
    }


def _summary(values: list[float]) -> dict[str, float | int]:
    if not values:
        return {"count": 0}
    array = np.asarray(values, dtype=np.float64)
    return {
        "count": int(array.size),
        "p50": float(np.percentile(array, 50)),
        "p95": float(np.percentile(array, 95)),
        "p99": float(np.percentile(array, 99)),
        "max": float(np.max(array)),
        "severe_gt5": int(np.sum(array > 5.0)),
        "severe_fraction_gt5": float(np.mean(array > 5.0)),
    }


def _preflight_jsonl(output: pathlib.Path | None, checkpoint: pathlib.Path) -> pathlib.Path | None:
    """Resolve and validate a diagnostic destination before model construction.

    The checkpoint argument names the selected item (normally ``<step>/params``), so its
    parent is the checkpoint step directory.  Even a nested or symlink-resolved destination
    there is rejected.  The existing-parent rule intentionally preserves the old CLI's
    behavior rather than creating directories as a side effect.
    """
    if output is None:
        return None
    resolved = output.expanduser().resolve(strict=False)
    step_dir = checkpoint.parent.resolve()
    if resolved == step_dir or step_dir in resolved.parents:
        raise ValueError(f"--jsonl must be outside the selected checkpoint step directory: {step_dir}")
    parent = resolved.parent
    if not parent.exists():
        raise FileNotFoundError(f"--jsonl parent directory does not exist: {parent}")
    if not parent.is_dir():
        raise NotADirectoryError(f"--jsonl parent is not a directory: {parent}")
    if resolved.exists() and not resolved.is_file():
        raise ValueError(f"--jsonl destination is not a regular file: {resolved}")

    # Actually exercise sibling-file creation rather than relying on os.access, whose answer
    # can differ from a later open because of ACLs or effective-ID behavior.
    probe_fd = None
    probe_name = None
    try:
        probe_fd, probe_name = tempfile.mkstemp(prefix=f".{resolved.name}.preflight-", dir=parent)
    except OSError as error:
        raise PermissionError(f"--jsonl parent is not writable: {parent}") from error
    finally:
        if probe_fd is not None:
            os.close(probe_fd)
        if probe_name is not None:
            pathlib.Path(probe_name).unlink(missing_ok=True)
    return resolved


def _emit_rows(rows: list[dict[str, Any]], output: pathlib.Path | None) -> None:
    if output is None:
        for row in rows:
            print(json.dumps(row, sort_keys=True))
        return

    fd, name = tempfile.mkstemp(prefix=f".{output.name}.", suffix=".tmp", dir=output.parent)
    temp_path = pathlib.Path(name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            for row in rows:
                line = json.dumps(row, sort_keys=True)
                print(line)
                stream.write(line + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_path, output)
        temp_path = None
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)


def _run_batch(
    batch_index: int,
    observation: _model.Observation,
    model: Any,
    interface,
    model_state,
    full_core,
    output_core,
    memory_params,
    *,
    include_momentum_reset: bool,
) -> list[dict[str, Any]]:
    b, steps = observation.seq_step_mask.shape
    mask_state = (
        getattr(model, "memory_state_mask_prob", 0.0) > 0
        and observation.seq_state_masked is not None
        and observation.token_state_mask is not None
    )
    segment_masked = observation.seq_state_masked if mask_state else None

    # First pass: generate the model-side write representation once and advance only the
    # configured full-plasticity baseline.  The second pass consumes these immutable arrays.
    baseline_state = model.memory.init_state(b)
    fixed: list[dict[str, Any]] = []
    for position in range(steps):
        frame = _frame_observation(observation, position)
        interface_out = interface(model_state, frame, baseline_state, segment_masked)
        valid = observation.seq_step_mask[:, position]
        fixed.append(
            {
                "key": interface_out["key"],
                "value": interface_out["value"],
                "theta": interface_out["theta"],
                "eta": interface_out["eta"],
                "alpha": interface_out["alpha"],
            }
        )
        candidate, _aux, _stats = full_core(
            memory_params,
            baseline_state,
            interface_out["key"],
            interface_out["value"],
            interface_out["theta"],
            interface_out["eta"],
            interface_out["alpha"],
        )
        baseline_state = apply_valid_state(candidate, baseline_state, valid)

    arm_specs = [
        ("full_configured_eta", "full", True),
        ("full_eta_zero", "full", False),
        ("output_only_configured_eta", "output_only", True),
        ("output_only_eta_zero", "output_only", False),
    ]
    if include_momentum_reset:
        arm_specs.append(("output_only_configured_eta_per_write_momentum_reset", "output_only_reset", True))
    states = {name: model.memory.init_state(b) for name, _kind, _configured in arm_specs}
    initial_states = dict(states)
    rows: list[dict[str, Any]] = []
    padded_steps = int(steps)
    for position, values in enumerate(fixed):
        valid = observation.seq_step_mask[:, position]
        for arm_name, kind, configured in arm_specs:
            pre_state = states[arm_name]
            eta = values["eta"] if configured else jnp.zeros_like(values["eta"])
            state = pre_state
            if kind == "output_only_reset":
                state = _memory.MemoryState(
                    fast_weights=state.fast_weights,
                    momentum=jax.tree.map(jnp.zeros_like, state.momentum),
                )
            if kind.startswith("output_only"):
                candidate, aux, stats = output_core(
                    memory_params,
                    state,
                    values["key"],
                    values["value"],
                    values["theta"],
                    eta,
                    values["alpha"],
                )
            else:
                candidate, aux, stats = full_core(
                    memory_params,
                    state,
                    values["key"],
                    values["value"],
                    values["theta"],
                    eta,
                    values["alpha"],
                )
            # The reset state is only a valid-row write input.  Selecting against it would
            # silently zero invalid-row momentum, violating the advertised exact no-op.
            post_state = apply_valid_state(candidate, pre_state, valid)
            states[arm_name] = post_state
            surprise, leaf_norms, full_global_norm, effective_grad_norm = stats
            pre_fast_norms, pre_momentum_norms = _state_summary(pre_state)
            post_fast_norms, post_momentum_norms = _state_summary(post_state)
            initial = initial_states[arm_name]
            write_fast_delta = _tree_norms(
                jax.tree.map(jnp.subtract, post_state.fast_weights, pre_state.fast_weights)
            )
            write_momentum_delta = _tree_norms(
                jax.tree.map(jnp.subtract, post_state.momentum, pre_state.momentum)
            )
            pre_fast_from_init = _tree_norms(
                jax.tree.map(jnp.subtract, pre_state.fast_weights, initial.fast_weights)
            )
            post_fast_from_init = _tree_norms(
                jax.tree.map(jnp.subtract, post_state.fast_weights, initial.fast_weights)
            )
            output_names = {f"w{model.memory._num_layers - 1}", f"b{model.memory._num_layers - 1}"}  # noqa: SLF001
            nonoutput_names = set(pre_fast_norms) - output_names
            for sample in range(b):
                valid_sample = bool(valid[sample])
                raw_leaf = _row_norm_dict(leaf_norms, sample=sample, valid=valid_sample, prefix="raw_grad_norms")
                sample_pre_fast = _row_norm_dict(
                    pre_fast_norms, sample=sample, valid=valid_sample, prefix="prewrite_fast_norms"
                )
                sample_post_fast = _row_norm_dict(
                    post_fast_norms, sample=sample, valid=valid_sample, prefix="postwrite_fast_norms"
                )
                sample_pre_momentum = _row_norm_dict(
                    pre_momentum_norms, sample=sample, valid=valid_sample, prefix="prewrite_momentum_norms"
                )
                sample_post_momentum = _row_norm_dict(
                    post_momentum_norms, sample=sample, valid=valid_sample, prefix="postwrite_momentum_norms"
                )
                sample_write_fast_delta = _row_norm_dict(
                    write_fast_delta, sample=sample, valid=valid_sample, prefix="write_fast_delta_norms"
                )
                sample_write_momentum_delta = _row_norm_dict(
                    write_momentum_delta, sample=sample, valid=valid_sample, prefix="write_momentum_delta_norms"
                )
                sample_pre_delta = _row_norm_dict(
                    pre_fast_from_init, sample=sample, valid=valid_sample, prefix="prewrite_fast_delta_from_init"
                )
                sample_post_delta = _row_norm_dict(
                    post_fast_from_init, sample=sample, valid=valid_sample, prefix="postwrite_fast_delta_from_init"
                )
                pre_fast_norm = _group_norm(sample_pre_fast, set(sample_pre_fast)) if valid_sample else None
                post_fast_norm = _group_norm(sample_post_fast, set(sample_post_fast)) if valid_sample else None
                pre_momentum_norm = (
                    _group_norm(sample_pre_momentum, set(sample_pre_momentum)) if valid_sample else None
                )
                post_momentum_norm = (
                    _group_norm(sample_post_momentum, set(sample_post_momentum)) if valid_sample else None
                )
                write_fast_norm = (
                    _group_norm(sample_write_fast_delta, set(sample_write_fast_delta)) if valid_sample else None
                )
                write_momentum_norm = (
                    _group_norm(sample_write_momentum_delta, set(sample_write_momentum_delta))
                    if valid_sample
                    else None
                )
                pre_delta_norm = _group_norm(sample_pre_delta, set(sample_pre_delta)) if valid_sample else None
                post_delta_norm = _group_norm(sample_post_delta, set(sample_post_delta)) if valid_sample else None
                row = {
                    "batch": batch_index,
                    "sample": sample,
                    "position": position,
                    "padded_steps": padded_steps,
                    "phase": _phase(observation, sample, position, valid=valid_sample),
                    "seq_block_boundary": (
                        bool(observation.seq_block_boundary[sample, position])
                        if observation.seq_block_boundary is not None
                        else False
                    ),
                    "valid": valid_sample,
                    "state_masked": bool(segment_masked[sample]) if segment_masked is not None else False,
                    "arm": arm_name,
                    "eta_mode": "configured" if configured else "zero",
                    "surprise": _row_metric(surprise, sample=sample, valid=valid_sample, name="surprise"),
                    "raw_grad_norm": _row_metric(
                        effective_grad_norm, sample=sample, valid=valid_sample, name="raw_grad_norm"
                    ),
                    "raw_grad_norm_full_tree": _row_metric(
                        full_global_norm, sample=sample, valid=valid_sample, name="raw_grad_norm_full_tree"
                    ),
                    "raw_grad_norms": raw_leaf,
                    "clip_factor": _row_metric(aux["clip_factor"], sample=sample, valid=valid_sample, name="clip_factor"),
                    "theta": _row_metric(aux["theta"], sample=sample, valid=valid_sample, name="theta"),
                    "eta": _row_metric(aux["eta"], sample=sample, valid=valid_sample, name="eta"),
                    "alpha": _row_metric(aux["alpha"], sample=sample, valid=valid_sample, name="alpha"),
                    "prewrite_fast_norms": sample_pre_fast,
                    "postwrite_fast_norms": sample_post_fast,
                    "prewrite_momentum_norms": sample_pre_momentum,
                    "postwrite_momentum_norms": sample_post_momentum,
                    "write_fast_delta_norms": sample_write_fast_delta,
                    "write_momentum_delta_norms": sample_write_momentum_delta,
                    "prewrite_fast_delta_from_init_norms": sample_pre_delta,
                    "postwrite_fast_delta_from_init_norms": sample_post_delta,
                    "prewrite_fast_norm": pre_fast_norm,
                    "postwrite_fast_norm": post_fast_norm,
                    "prewrite_momentum_norm": pre_momentum_norm,
                    "postwrite_momentum_norm": post_momentum_norm,
                    "write_fast_delta_norm": write_fast_norm,
                    "write_momentum_delta_norm": write_momentum_norm,
                    "prewrite_fast_delta_from_init_norm": pre_delta_norm,
                    "postwrite_fast_delta_from_init_norm": post_delta_norm,
                    "postwrite_output_fast_delta_from_init_norm": (
                        _group_norm(sample_post_delta, output_names) if valid_sample else None
                    ),
                    "postwrite_nonoutput_fast_delta_from_init_norm": (
                        _group_norm(sample_post_delta, nonoutput_names) if valid_sample else None
                    ),
                }
                rows.append(row)
    baseline_diff = _state_max_abs_diff(states["full_configured_eta"], baseline_state)
    if baseline_diff != 0.0:
        raise AssertionError(
            "same-K/V full-configured replay diverged from its generation baseline: "
            f"max_abs_diff={baseline_diff}"
        )
    return rows


def _assert_pinned_run4_config(config: Any) -> None:
    """Fail closed if any run-4 setting that changes this replay has drifted."""
    expected_model_fields = {
        "max_token_len": 80,
        "memory_architecture": "v32_layer8_dual_query",
        "memory_layer": 8,
        "memory_write_source": "query_compressed",
        "memory_query_tokens": 16,
        "memory_query_heads": 8,
        "memory_seq_steps": 40,
        "memory_block_steps": 25,
        "memory_task_conditioned_write": True,
        "memory_qk_norm": True,
        "memory_letterbox_source_hw": (480, 640),
        "memory_conditioner_context": "instruction_only",
        "memory_state_mask_prob": 0.5,
        "memory_state_mask_dual_view": False,
    }
    expected_memory_fields = {
        "d_input": 2048,
        "d_key": 512,
        "hidden_dims": (1024, 1024, 1024),
        "d_value": 2048,
        "theta_bias": -2.2,
        "eta_bias": 2.2,
        "alpha_bias": -4.6,
        "max_grad_norm": 1.0,
        "mlp_l2norm": True,
        "blank_initial_output": True,
        "drift_radius": None,
    }
    mismatches = {
        f"model.{name}": (getattr(config.model, name), expected)
        for name, expected in expected_model_fields.items()
        if getattr(config.model, name) != expected
    }
    mismatches.update(
        {
            f"model.memory.{name}": (getattr(config.model.memory, name), expected)
            for name, expected in expected_memory_fields.items()
            if getattr(config.model.memory, name) != expected
        }
    )
    if mismatches:
        raise ValueError(f"incident replay config drifted from pinned run4 semantics: {mismatches}")


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=CONFIG_NAME)
    parser.add_argument("--checkpoint", type=pathlib.Path, default=DEFAULT_CHECKPOINT)
    parser.add_argument(
        "--parameter-source",
        choices=("raw", "ema"),
        default="raw",
        help="raw model params from sibling train_state (default) or EMA params from --checkpoint/params",
    )
    parser.add_argument("--batches", type=int, default=1)
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument(
        "--momentum-reset",
        action="store_true",
        help="include an explicitly labelled per-write momentum-reset arm (not a boundary reset)",
    )
    parser.add_argument("--jsonl", type=pathlib.Path, help="also write diagnostic rows here (never a checkpoint path)")
    args = parser.parse_args(argv)
    if args.config != CONFIG_NAME:
        raise ValueError(f"this incident replay is pinned to {CONFIG_NAME!r}; got {args.config!r}")
    args.checkpoint = args.checkpoint.resolve()
    if not args.checkpoint.exists():
        raise FileNotFoundError(args.checkpoint)
    restore_path = _parameter_restore_path(args.checkpoint, args.parameter_source)
    if not restore_path.exists():
        raise FileNotFoundError(f"parameter source path not found: {restore_path}")
    args.jsonl = _preflight_jsonl(args.jsonl, args.checkpoint)

    config = _config.get_config(args.config)
    config = dataclasses.replace(config, batch_size=args.batch_size, num_workers=args.num_workers)
    _assert_pinned_run4_config(config)
    # Match the training compute dtype: tower leaves are bf16 while v3.4 memory leaves remain
    # float32.  This is important on a single H100 and is also the dtype of the run-4 replay.
    model = build_init_model(config, bf16_tower=True)
    graphdef, state = nnx.split(model)
    if args.parameter_source == "raw":
        loaded = _restore_raw_params(args.checkpoint, state)
    else:
        loaded = _model.restore_params(args.checkpoint, restore_type=np.ndarray)
    flat = {}
    for key, value in traverse_util.flatten_dict(loaded, sep="/").items():
        if value is None:
            continue
        dtype = jnp.bfloat16 if key.startswith("PaliGemma/") and value.dtype == np.float32 else None
        flat[key] = jnp.asarray(value, dtype=dtype) if dtype else jnp.asarray(value)
    state.replace_by_pure_dict(traverse_util.unflatten_dict(flat, sep="/"))
    model = nnx.merge(graphdef, state)
    model.eval()
    print(f"config={args.config}")
    if args.parameter_source == "raw":
        print(f"parameter_source=raw model params restored from {restore_path}/params via Orbax transform (not optimizer/EMA)")
    else:
        print(f"parameter_source=EMA params tree restored from {restore_path} (not raw optimizer params)")
    np.random.seed(config.seed)
    print("replay_mode=eval distribution; no image augmentation; model-side early interface once per position")
    print("write_inputs=one fixed project_kv K/V and gates replayed by every arm")
    print("invalid_write_policy=exact state no-op via valid-row selection")
    print("memory_critical=not exposed by the loader batch; phase/position fields are logged without guessing")

    interface, model_state = _make_interface_jit(model)
    full_core, output_core, memory_params = _make_core_fns(model)
    # shuffle=True is significant for memory training: it activates the weighted sequence/bucket
    # sampler and held-out exclusion.  The fixed config seed plus this explicit main-process NumPy
    # seed keeps the no-worker diagnostic reproducible.
    loader = _data_loader.create_data_loader(config, shuffle=True, num_batches=args.batches)
    all_rows: list[dict[str, Any]] = []
    for batch_index, (observation, _actions) in enumerate(loader):
        all_rows.extend(
            _run_batch(
                batch_index,
                observation,
                model,
                interface,
                model_state,
                full_core,
                output_core,
                memory_params,
                include_momentum_reset=args.momentum_reset,
            )
        )
        print(f"completed batch={batch_index} positions={observation.seq_step_mask.shape[1]}")

    _emit_rows(all_rows, args.jsonl)
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in all_rows:
        if row["valid"]:
            grouped[row["arm"]].append(row)
    print("\naggregate_raw_grad_norms:")
    for arm, rows in grouped.items():
        print(json.dumps({"arm": arm, "raw_grad_norm": _summary([row["raw_grad_norm"] for row in rows])}, sort_keys=True))
        print(
            json.dumps(
                {"arm": arm, "raw_grad_norm_full_tree": _summary([row["raw_grad_norm_full_tree"] for row in rows])},
                sort_keys=True,
            )
        )
        for metric in (
            "surprise",
            "prewrite_fast_norm",
            "postwrite_fast_norm",
            "prewrite_momentum_norm",
            "postwrite_momentum_norm",
            "write_fast_delta_norm",
            "write_momentum_delta_norm",
            "prewrite_fast_delta_from_init_norm",
            "postwrite_fast_delta_from_init_norm",
            "postwrite_output_fast_delta_from_init_norm",
            "postwrite_nonoutput_fast_delta_from_init_norm",
        ):
            print(json.dumps({"arm": arm, metric: _summary([row[metric] for row in rows])}, sort_keys=True))
        for leaf in sorted(rows[0]["raw_grad_norms"]):
            print(json.dumps({"arm": arm, "leaf": leaf, "raw_grad_norm": _summary([row["raw_grad_norms"][leaf] for row in rows])}, sort_keys=True))


if __name__ == "__main__":
    main()
