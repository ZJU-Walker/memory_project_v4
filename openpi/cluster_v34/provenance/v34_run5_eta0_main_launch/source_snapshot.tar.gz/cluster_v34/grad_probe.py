"""Locate non-finite gradient leaves in the v3.4 training objective at init (one real batch)."""
# ruff: noqa: I001
import pyarrow.parquet as pq  # noqa: F401
import torch  # noqa: F401

import dataclasses
import sys

import flax.nnx as nnx
import jax
import jax.numpy as jnp
import numpy as np

sys.path.insert(0, "/iris/u/kewalk/memory_project/openpi/scripts")
from v34_init_scale import build_init_model

import openpi.training.config as _config
import openpi.training.data_loader as _data_loader

def main():
    config = _config.get_config("pi05_yam_mem_v34")
    config = dataclasses.replace(config, batch_size=4, num_workers=0)
    model = build_init_model(config)
    model.train()

    loader = _data_loader.create_data_loader(config, shuffle=True, num_batches=1)
    observation, actions = next(iter(loader))

    graphdef, params = nnx.split(model)


    def loss_fn(p, component):
        m = nnx.merge(graphdef, p)
        chunked = m._compute_sequence_loss_v32(jax.random.key(0), observation, actions, train=True)  # noqa: SLF001
        flow = jnp.mean(chunked["flow"])
        ce = jnp.mean(chunked["ce"])
        present = chunked["aux_count_class"] > 0
        per_class = jnp.where(present, chunked["aux_ce_class_sum"] / jnp.maximum(chunked["aux_count_class"], 1.0), 0.0)
        aux = jnp.sum(per_class) / jnp.maximum(jnp.sum(present), 1)
        ladder = sum(
            chunked[f"{r}_ce_sum"] / jnp.maximum(chunked[f"{r}_count"], 1.0) for r in ("ladder_writer", "ladder_read")
        )
        return {"flow": flow, "ce": ce, "aux": 0.1 * aux, "ladder": ladder, "all": flow + ce + 0.1 * aux + ladder}[
            component
        ]


    for component in ("all", "ce", "flow", "aux", "ladder"):
        value, grads = jax.jit(jax.value_and_grad(loss_fn), static_argnums=1)(params, component)
        bad, big = [], []
        total_sq = 0.0
        for path, leaf in jax.tree_util.tree_leaves_with_path(grads):
            arr = np.asarray(leaf, dtype=np.float64)
            if not np.isfinite(arr).all():
                bad.append(jax.tree_util.keystr(path))
            else:
                norm = float(np.sqrt(np.sum(arr**2)))
                total_sq += norm**2
                if norm > 1e4:
                    big.append((jax.tree_util.keystr(path), norm))
        print(f"\n== component {component}: loss={float(value):.4f} finite_global_norm={np.sqrt(total_sq):.3e}")
        print(f"   nonfinite leaves ({len(bad)}):")
        for key in bad[:20]:
            print("     ", key)
        for key, norm in sorted(big, key=lambda kv: -kv[1])[:10]:
            print(f"   big: {norm:.3e}  {key}")
        if component == "all" and not bad:
            print("   (no nonfinite in 'all'; checking components anyway)")


if __name__ == "__main__":
    main()
