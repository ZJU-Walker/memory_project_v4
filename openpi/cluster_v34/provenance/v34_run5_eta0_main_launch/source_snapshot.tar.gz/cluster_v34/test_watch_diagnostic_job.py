from __future__ import annotations

import importlib.util
import pathlib
import sys

import pytest

_SCRIPT = pathlib.Path(__file__).with_name("watch_diagnostic_job.py")
_SPEC = importlib.util.spec_from_file_location("watch_diagnostic_job", _SCRIPT)
assert _SPEC is not None
assert _SPEC.loader is not None
_MODULE = importlib.util.module_from_spec(_SPEC)
sys.modules[_SPEC.name] = _MODULE
_SPEC.loader.exec_module(_MODULE)


@pytest.mark.parametrize(
    ("squeue_output", "sacct_x_output", "sacct_output", "expected", "expected_calls"),
    [
        ("17024084.56", "", "", ("RUNNING", "present in squeue --steps"), 1),
        ("", "17024084.56|COMPLETED|0:0", "", ("COMPLETED", "ExitCode=0:0"), 2),
        ("", "", "17024084.56|FAILED|1:0", ("FAILED", "ExitCode=1:0"), 3),
    ],
)
def test_step_scheduler_state_uses_exact_active_or_accounting_row(
    monkeypatch: pytest.MonkeyPatch,
    squeue_output: str,
    sacct_x_output: str,
    sacct_output: str,
    expected: tuple[str, str],
    expected_calls: int,
) -> None:
    calls: list[tuple[str, ...]] = []

    def fake_run(*args: str) -> str:
        calls.append(args)
        if args[0] == "squeue":
            return squeue_output
        if "-X" in args:
            return sacct_x_output
        return sacct_output

    monkeypatch.setattr(_MODULE, "_run", fake_run)

    assert _MODULE._scheduler_state("17024084.56") == expected  # noqa: SLF001
    assert calls[0] == (
        "squeue",
        "--noheader",
        "--steps",
        "--jobs",
        "17024084",
        "--format=%i",
    )
    assert len(calls) == expected_calls


def test_step_scheduler_state_does_not_confuse_a_sibling_step(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[str, ...]] = []

    def fake_run(*args: str) -> str:
        calls.append(args)
        if args[0] == "squeue":
            return "17024084.55\n17024084.57"
        if "-X" in args:
            return "17024084.55|COMPLETED|0:0"
        return "17024084.56|FAILED|1:0\n17024084.57|COMPLETED|0:0"

    monkeypatch.setattr(_MODULE, "_run", fake_run)

    assert _MODULE._scheduler_state("17024084.56") == ("FAILED", "ExitCode=1:0")  # noqa: SLF001
    assert len(calls) == 3


@pytest.mark.parametrize(
    ("reported", "expected"),
    [
        ("CANCELLED by 24706", "CANCELLED"),
        ("FAILED+", "FAILED"),
        (" OUT_OF_MEMORY ", "OUT_OF_MEMORY"),
        ("", "UNKNOWN"),
    ],
)
def test_canonical_state_removes_slurm_annotations(reported: str, expected: str) -> None:
    assert _MODULE._canonical_state(reported) == expected  # noqa: SLF001


def test_numeric_job_cancelled_by_user_is_terminal(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_run(*args: str) -> str:
        if args[0] == "squeue":
            return ""
        return "CANCELLED by 24706|0:0"

    monkeypatch.setattr(_MODULE, "_run", fake_run)
    assert _MODULE._scheduler_state("17073322") == (  # noqa: SLF001
        "CANCELLED",
        "ExitCode=0:0",
    )


@pytest.mark.parametrize(
    "job_id",
    ["17024084.56", "17024084", "0.0"],
)
def test_main_accepts_numeric_job_and_step_ids(
    monkeypatch: pytest.MonkeyPatch, tmp_path: pathlib.Path, job_id: str
) -> None:
    monkeypatch.setattr(
        sys,
        "argv",
        [
            str(_SCRIPT),
            "--job-id",
            job_id,
            "--audit-log",
            str(tmp_path / "audit.log"),
            "--stdout",
            str(tmp_path / "stdout.log"),
            "--stderr",
            str(tmp_path / "stderr.log"),
        ],
    )
    monkeypatch.setattr(_MODULE, "_scheduler_state", lambda _: ("COMPLETED", "ExitCode=0:0"))

    assert _MODULE.main() == 0


@pytest.mark.parametrize("job_id", ["17024084.", ".56", "17024084.56.1", "batch", "1702a.56"])
def test_main_rejects_non_numeric_job_or_step_ids(
    monkeypatch: pytest.MonkeyPatch, tmp_path: pathlib.Path, job_id: str
) -> None:
    monkeypatch.setattr(
        sys,
        "argv",
        [
            str(_SCRIPT),
            "--job-id",
            job_id,
            "--audit-log",
            str(tmp_path / "audit.log"),
            "--stdout",
            str(tmp_path / "stdout.log"),
            "--stderr",
            str(tmp_path / "stderr.log"),
        ],
    )

    with pytest.raises(ValueError, match="non-numeric diagnostic job or step id"):
        _MODULE.main()


def test_main_returns_failure_for_terminal_failed_step(monkeypatch: pytest.MonkeyPatch, tmp_path: pathlib.Path) -> None:
    monkeypatch.setattr(
        sys,
        "argv",
        [
            str(_SCRIPT),
            "--job-id",
            "17024084.56",
            "--audit-log",
            str(tmp_path / "audit.log"),
            "--stdout",
            str(tmp_path / "stdout.log"),
            "--stderr",
            str(tmp_path / "stderr.log"),
        ],
    )
    monkeypatch.setattr(_MODULE, "_scheduler_state", lambda _: ("FAILED", "ExitCode=1:0"))

    assert _MODULE.main() == 2
