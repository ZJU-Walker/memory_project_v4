"""Per-leaf gradient walk of the v3.4 objective AT A CHECKPOINT (not init).

Diagnoses the run-1 explosion limit cycle (grad_norm 5 -> 50 -> 2e5 every ~700 steps from
step ~1300): loads the ckpt-2250 weights, evaluates the training loss gradient on several
real batches, and prints the largest per-leaf norms per loss component. Read-only.

Run on a free GPU (NOT the training node):
    HOME=/iris/u/kewalk srun --overlap --jobid <job> python cluster_v34/grad_probe_ckpt.py
"""
# ruff: noqa: I001, B023
import pyarrow.parquet as pq  # noqa: F401
import torch  # noqa: F401

import dataclasses
import sys

import flax.nnx as nnx
import flax.traverse_util as traverse_util
import jax
import jax.numpy as jnp
import numpy as np

sys.path.insert(0, "/iris/u/kewalk/memory_project/openpi/scripts")
from v34_init_scale import build_init_model

import openpi.models.model as _model
import openpi.training.config as _config
import openpi.training.data_loader as _data_loader

CKPT = "/iris/u/kewalk/memory_project/openpi/checkpoints/pi05_yam_mem_v34/v34_run1/2750/params"
BATCHES = 8


def load_ckpt_model(config):
    model = build_init_model(config)
    graphdef, state = nnx.split(model)
    loaded = _model.restore_params(CKPT, restore_type=np.ndarray)
    flat = {
        key: jnp.asarray(value)
        for key, value in traverse_util.flatten_dict(loaded, sep="/").items()
        if value is not None
    }
    state.replace_by_pure_dict(traverse_util.unflatten_dict(flat, sep="/"))
    print(f"loaded {len(flat)} leaves from {CKPT}")
    return nnx.merge(graphdef, state)


def main():
    config = _config.get_config("pi05_yam_mem_v34")
    config = dataclasses.replace(config, batch_size=4, num_workers=0)
    model = load_ckpt_model(config)
    model.train()

    loader = _data_loader.create_data_loader(config, shuffle=True, num_batches=BATCHES)
    graphdef, params = nnx.split(model)

    def loss_fn(p, observation, actions, component):
        m = nnx.merge(graphdef, p)
        chunked = m._compute_sequence_loss_v32(jax.random.key(0), observation, actions, train=True)  # noqa: SLF001
        flow = jnp.mean(chunked["flow"])
        ce = jnp.mean(chunked["ce"])
        present = chunked["aux_count_class"] > 0
        per_class = jnp.where(present, chunked["aux_ce_class_sum"] / jnp.maximum(chunked["aux_count_class"], 1.0), 0.0)
        aux = jnp.sum(per_class) / jnp.maximum(jnp.sum(present), 1)
        return {"flow": flow, "ce": ce, "aux": 0.1 * aux, "all": flow + ce + 0.1 * aux}[component]

    grad_fn = jax.jit(jax.value_and_grad(loss_fn), static_argnums=3)

    for batch_index, (observation, actions) in enumerate(loader):
        components = ("all", "aux", "ce") if batch_index < 2 else ("all",)
        for component in components:
            value, grads = grad_fn(params, observation, actions, component)
            rows, bad, total_sq, gate_sq = [], [], 0.0, 0.0
            for path, leaf in jax.tree_util.tree_leaves_with_path(grads):
                arr = np.asarray(leaf, dtype=np.float64)
                key = jax.tree_util.keystr(path)
                if not np.isfinite(arr).all():
                    bad.append(key)
                    continue
                norm = float(np.sqrt(np.sum(arr**2)))
                total_sq += norm**2
                if "['memory']['gate']" in key:
                    gate_sq += norm**2  # frozen + zero-kernel: invisible to the real train step
                rows.append((norm, key))
            del grads
            rows.sort(reverse=True)
            print(
                f"\n== batch {batch_index} component {component}: loss={float(value):.4f} "
                f"global_norm={np.sqrt(total_sq):.3e} train_visible_norm={np.sqrt(total_sq - gate_sq):.3e} "
                f"nonfinite={len(bad)}"
            )
            for key in bad[:10]:
                print("   NONFINITE:", key)
            for norm, key in rows[:12]:
                print(f"   {norm:.3e}  {key}")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
