"""v3.4 offline probe ladder (V34_PLAN_final.md Section 6) -- the numbers you believe.

Four rungs, factorized so a failure localizes (writer -> commit -> reader -> retention):

  1. WRITER CONTENT   decode the side from the write tokens W_t on evidence frames;
  2. COMMIT           own-key recall read_key(M_t, K_t) with the exact keys that participated
                      in the write (post-write), decoded + tracked as ||readback - V_t||;
  3. IMMEDIATE READER post-write standard-read retrieval on evidence frames;
  4. RETENTION        pre-write standard-read retrieval (M_{t-1}) on waiting frames.

Contamination control: rungs 3-4 use h8-derived queries, which are intrinsically contaminated
(M(q) ~ phi(q) can act as a fixed function of the query). Their headline numbers are
probe-DELTA: accuracy with the episodic memory minus accuracy with a RESET memory M_0, same
inputs, same probe protocol. Rungs 1-2 need no delta (frame-invariant inputs). Every rung is
reported next to the raw proprioceptive-state control -- a rung that does not clear the state
baseline is not evidence of memory.

Split protocol: the headline is train-on-training-episodes -> test-on-HELDOUT-episodes (the
four episodes excluded from all v3.4 training sampling); leave-one-episode-out over the
training episodes is the sample-efficient secondary. Features are pooled per (episode, phase)
so an episode contributes one point per stream and long episodes cannot dominate; per-slot
means are kept for the slot-decodability check (mean pooling can hide single-slot storage).

Replays real episodes at the training write cadence with the CPU-efficient early-only
interface (blocks 0..8) and the real recurrent write state, exactly like the training loop.
"""

# ruff: noqa: SLF001, I001 - reuses the v3.2/v3.3 replay machinery; the pyarrow-before-openpi
# import order is load-bearing (see v33_writer_attention for why).

from __future__ import annotations

import pyarrow.parquet as pq

import dataclasses
import json
import pathlib
import time
from typing import Any

import numpy as np

import openpi.diagnostics.v33_memory_interface as _interface
import openpi.diagnostics.v33_write_token_probe as _probe
from openpi.diagnostics import writer_contribution as _wc
import openpi.shared.nnx_utils as nnx_utils

DEFAULT_HELDOUT = (15, 29, 44, 59)
RUNGS = ("writer", "commit", "read_post", "read_pre")
CONTROLS = ("read_reset", "state")
PHASES = ("evidence", "retention", "waiting")


@dataclasses.dataclass
class Options:
    checkpoint: str
    dataset_root: str
    output_dir: str
    config: str = "pi05_yam_mem_v34"
    episode_indices: tuple[int, ...] | None = None  # None = all label-usable episodes
    heldout_episodes: tuple[int, ...] = DEFAULT_HELDOUT
    stride: int = 15
    progress_every: int = 10


class _Accumulator:
    """Streaming per-(episode, phase) mean of pooled features and per-slot features."""

    def __init__(self):
        self.pooled: dict[str, np.ndarray] = {}
        self.slots: dict[str, np.ndarray] = {}
        self.count = 0
        self.commit_errors: list[float] = []

    def add(self, pooled: dict[str, np.ndarray], slots: dict[str, np.ndarray], commit_error: float):
        for key, value in pooled.items():
            self.pooled[key] = self.pooled.get(key, 0.0) + value
        for key, value in slots.items():
            self.slots[key] = self.slots.get(key, 0.0) + value
        self.commit_errors.append(commit_error)
        self.count += 1

    def means(self) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray]]:
        return (
            {key: value / self.count for key, value in self.pooled.items()},
            {key: value / self.count for key, value in self.slots.items()},
        )


def _l2n(x: np.ndarray) -> np.ndarray:
    return x / (np.linalg.norm(x, axis=-1, keepdims=True) + 1e-8)


class V34ProbeLadderRunner(_interface.V33MemoryInterfaceRunner):
    def __init__(self, options: Options):
        super().__init__(
            _interface.Options(
                checkpoint=options.checkpoint,
                dataset_root=options.dataset_root,
                output_dir=options.output_dir,
                config=options.config,
                episode_indices=options.episode_indices,
                stride=options.stride,
                progress_every=options.progress_every,
            )
        )
        self.ladder_options = options
        self._read_key = nnx_utils.module_jit(self.model.memory.read_key)
        self._read = nnx_utils.module_jit(self.model.memory.read)

    def harvest(self) -> dict[str, Any]:
        plans = _probe._plan_all_episodes(self.options, self.data_config)
        if self.ladder_options.episode_indices is not None:
            wanted = set(self.ladder_options.episode_indices)
            plans = [plan for plan in plans if plan.episode in wanted]
        if not plans:
            raise ValueError("no episodes selected")
        columns = ["image", "left_wrist_image", "right_wrist_image", "state", "frame_index", "task_index"]
        sources = _wc._load_lerobot_sources(self.options.dataset_root, [plan.episode for plan in plans])
        selected_by_episode = []
        for plan, source in zip(plans, sources, strict=True):
            rows = pq.read_table(source.path, columns=columns).to_pylist()
            selected = [
                row
                for row in rows
                if int(row["frame_index"]) % self.stride == 0 and int(row["frame_index"]) <= plan.memory[1]
            ]
            selected_by_episode.append(selected)

        batch = len(plans)
        schedule = _interface.padded_stream_schedule([len(rows) for rows in selected_by_episode])
        memory_state = self.model.memory.init_state(batch)
        reset_state = self.model.memory.init_state(batch)
        final_observations: list[Any | None] = [None for _ in plans]
        accumulators: dict[tuple[int, str], _Accumulator] = {}
        started = time.monotonic()
        print(f"ladder replay B={batch}: {[len(r) for r in selected_by_episode]} frames", flush=True)

        for step, (source_indices, active) in enumerate(schedule):
            observations = []
            for episode_index, (plan, source_index, is_active) in enumerate(
                zip(plans, source_indices, active, strict=True)
            ):
                if is_active:
                    row = selected_by_episode[episode_index][source_index]
                    observation, _ = self._observation(row, int(row["frame_index"]), plan.prompt)
                    if source_index + 1 == len(selected_by_episode[episode_index]):
                        final_observations[episode_index] = observation
                else:
                    observation = final_observations[episode_index]
                observations.append(observation)

            output = self._interface(_interface._batch_observations(observations), memory_state)
            next_state, _write_aux = self._write(memory_state, output["write_tokens"])
            # rung 2: own-key recall with the EXACT keys/values that participated in the write
            readback = np.asarray(self._read_key(next_state, output["write_keys"]))
            write_values = np.asarray(output["write_values"])
            commit_error = np.mean(np.sum((readback - write_values) ** 2, axis=-1), axis=-1)  # [b]
            # rung 3: post-write standard read; controls: reset-memory read
            read_post = np.asarray(self._read(next_state, output["read_queries"]))
            read_reset = np.asarray(self._read(reset_state, output["read_queries"]))
            write_tokens = np.asarray(output["write_tokens"])
            retrieved_pre = np.asarray(output["retrieved"])

            for episode_index, (plan, source_index, is_active) in enumerate(
                zip(plans, source_indices, active, strict=True)
            ):
                if not is_active:
                    continue
                row = selected_by_episode[episode_index][source_index]
                phase = _interface._phase(int(row["frame_index"]), plan)
                if phase not in PHASES:
                    continue
                streams_full = {
                    "writer": write_tokens[episode_index],
                    "commit": readback[episode_index],
                    "read_post": read_post[episode_index],
                    "read_pre": retrieved_pre[episode_index],
                    "read_reset": read_reset[episode_index],
                }
                pooled = {key: value.mean(axis=0) for key, value in streams_full.items()}
                pooled["state"] = np.asarray(row["state"], dtype=np.float32)
                slots = {"writer": streams_full["writer"], "read_pre": streams_full["read_pre"]}
                key = (plan.episode, phase)
                accumulators.setdefault(key, _Accumulator()).add(
                    pooled, slots, float(commit_error[episode_index])
                )
            memory_state = next_state
            if (step + 1) % self.options.progress_every == 0 or step + 1 == len(schedule):
                print(f"  call {step + 1}/{len(schedule)} ({time.monotonic() - started:.1f}s)", flush=True)

        episodes = []
        for plan in plans:
            per_phase = {}
            for phase in PHASES:
                accumulator = accumulators.get((plan.episode, phase))
                if accumulator is None or accumulator.count == 0:
                    continue
                pooled, slots = accumulator.means()
                per_phase[phase] = {
                    "pooled": {key: value.tolist() for key, value in pooled.items()},
                    "slots": {key: value.tolist() for key, value in slots.items()},
                    "frames": accumulator.count,
                    "commit_error_mean": float(np.mean(accumulator.commit_errors)),
                    "commit_error_last": float(accumulator.commit_errors[-1]),
                }
            episodes.append(
                {
                    "episode": plan.episode,
                    "side": {"left": 0, "right": 1}.get(plan.side, -1),
                    "prompt": plan.prompt,
                    "heldout": plan.episode in set(self.ladder_options.heldout_episodes),
                    "phases": per_phase,
                }
            )
        return {"episodes": episodes, "checkpoint": self.options.checkpoint}


def _collect(episodes, phase, stream, *, heldout):
    features, labels = [], []
    for entry in episodes:
        if entry["heldout"] != heldout or entry["side"] < 0:
            continue
        payload = entry["phases"].get(phase)
        if payload is None or stream not in payload["pooled"]:
            continue
        features.append(np.asarray(payload["pooled"][stream], dtype=np.float64))
        labels.append(entry["side"])
    if not features:
        return None, None
    return _l2n(np.stack(features)), np.asarray(labels)


def _heldout_accuracy(train_x, train_y, test_x, test_y) -> float | None:
    if train_x is None or test_x is None or len(np.unique(train_y)) < 2:
        return None
    train_std, test_std = _probe._standardize(train_x, test_x)
    weights = _probe.fit_logistic(train_std, train_y)
    scores = _probe.predict_logit(weights, test_std)
    return float(np.mean((scores > 0).astype(np.int64) == test_y))


def analyze(harvested: dict[str, Any]) -> dict[str, Any]:
    episodes = harvested["episodes"]
    report: dict[str, Any] = {"phases": {}}
    rng = np.random.default_rng(0)
    for phase in PHASES:
        phase_report = {}
        for stream in (*RUNGS, *CONTROLS):
            train_x, train_y = _collect(episodes, phase, stream, heldout=False)
            test_x, test_y = _collect(episodes, phase, stream, heldout=True)
            if train_x is None:
                continue
            loo = _probe.leave_one_out_probe(train_x, train_y)
            null = _probe.shuffled_null(train_x, train_y, seed=int(rng.integers(1 << 30)))
            entry = {
                "episodes": len(train_y),
                "loo_auc": float(loo["auc"]),
                "loo_accuracy": float(loo["accuracy"]),
                "shuffled_null_auc": float(null["auc_mean"]),
                "heldout_correct_of": None,
            }
            if test_x is not None:
                accuracy = _heldout_accuracy(train_x, train_y, test_x, test_y)
                if accuracy is not None:
                    entry["heldout_correct_of"] = [round(accuracy * len(test_y)), len(test_y)]
            phase_report[stream] = entry
        # probe-DELTA for the reader rungs: episodic-memory reads minus reset-memory reads
        if "read_reset" in phase_report:
            for rung in ("read_post", "read_pre"):
                if rung in phase_report:
                    phase_report[rung]["delta_auc_vs_reset"] = (
                        phase_report[rung]["loo_auc"] - phase_report["read_reset"]["loo_auc"]
                    )
        report["phases"][phase] = phase_report
    commit_by_phase = {}
    for phase in PHASES:
        errors = [
            entry["phases"][phase]["commit_error_mean"]
            for entry in episodes
            if phase in entry["phases"]
        ]
        if errors:
            commit_by_phase[phase] = {"mean": float(np.mean(errors)), "max": float(np.max(errors))}
    report["commit_error"] = commit_by_phase
    return report


def print_report(report: dict[str, Any]) -> None:
    print("\n================ v3.4 OFFLINE PROBE LADDER ================")
    print("(side decoding; coin flip = 0.5 AUC / 2-of-4 heldout)")
    for phase, streams in report["phases"].items():
        print(f"\n-- {phase} --")
        for stream in (*RUNGS, *CONTROLS):
            if stream not in streams:
                continue
            entry = streams[stream]
            heldout = entry.get("heldout_correct_of")
            heldout_text = f"heldout {heldout[0]}/{heldout[1]}" if heldout else "heldout n/a"
            delta = entry.get("delta_auc_vs_reset")
            delta_text = f"  probe-DELTA vs reset {delta:+.3f}" if delta is not None else ""
            print(
                f"  {stream:>10}: LOO AUC {entry['loo_auc']:.3f} (null {entry['shuffled_null_auc']:.3f}, "
                f"n={entry['episodes']})  {heldout_text}{delta_text}"
            )
    print("\ncommit (own-key recall) error by phase:", json.dumps(report.get("commit_error", {}), indent=2))
    print(
        "\nreading the ladder: rung1 fail -> writer; 1 pass 2 fail -> inner optimizer;\n"
        "2 pass 3 fail -> key mismatch; 3 pass 4 fail -> retention/interference (split with the\n"
        "three-way write_mode control); all pass but behavior doesn't flip -> consumption."
    )


def run(options: Options) -> dict[str, Any]:
    runner = V34ProbeLadderRunner(options)
    harvested = runner.harvest()
    output_dir = pathlib.Path(options.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "ladder_features.json").write_text(json.dumps(harvested))
    report = analyze(harvested)
    (output_dir / "ladder_report.json").write_text(json.dumps(report, indent=2))
    print_report(report)
    return report
