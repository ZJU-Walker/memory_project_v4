"""Analysis-layer tests for the v3.4 offline probe ladder (no model/checkpoint required)."""

# ruff: noqa: I001 - the pyarrow-before-openpi import order is load-bearing
import pyarrow.parquet as pq  # noqa: F401

import numpy as np

import openpi.diagnostics.v34_probe_ladder as ladder


def _episode(index, side, *, signal, heldout=False, dim=16, noise=0.05, rng=None):
    rng = rng or np.random.default_rng(index)
    phases = {}
    for phase in ladder.PHASES:
        pooled = {}
        for stream in (*ladder.RUNGS, *ladder.CONTROLS):
            base = rng.normal(0, noise, dim)
            if stream in signal.get(phase, ()):
                base[0] += 3.0 if side == 1 else -3.0
            pooled[stream] = base.tolist()
        phases[phase] = {
            "pooled": pooled,
            "slots": {},
            "frames": 5,
            "commit_error_mean": 0.1,
            "commit_error_last": 0.05,
        }
    return {"episode": index, "side": side, "prompt": "p", "heldout": heldout, "phases": phases}


def test_analyze_separates_informative_from_uninformative_streams():
    rng = np.random.default_rng(0)
    signal = {"waiting": ("writer", "read_pre"), "evidence": ("writer",)}
    episodes = [_episode(i, i % 2, signal=signal, rng=rng) for i in range(24)]
    for i, side in ((100, 0), (101, 1), (102, 0), (103, 1)):
        episodes.append(_episode(i, side, signal=signal, heldout=True, rng=rng))

    report = ladder.analyze({"episodes": episodes})
    waiting = report["phases"]["waiting"]
    assert waiting["writer"]["loo_auc"] > 0.8
    assert waiting["read_pre"]["loo_auc"] > 0.8
    # a signal-free control stream stays near its shuffled null
    assert abs(waiting["read_reset"]["loo_auc"] - 0.5) < 0.35
    # probe-DELTA: informative reads clear the reset control
    assert waiting["read_pre"]["delta_auc_vs_reset"] > 0.2
    # heldout protocol: 4 test episodes, near-perfect on the informative stream
    correct, total = waiting["writer"]["heldout_correct_of"]
    assert total == 4
    assert correct >= 3
    # commit error summary present per phase
    assert set(report["commit_error"]) == set(ladder.PHASES)


def test_analyze_handles_missing_streams_and_single_class():
    episodes = [_episode(i, 0, signal={}) for i in range(6)]  # one class only
    report = ladder.analyze({"episodes": episodes})
    for phase_report in report["phases"].values():
        for entry in phase_report.values():
            assert np.isfinite(entry["loo_auc"]) or entry["loo_auc"] != entry["loo_auc"]  # nan tolerated
