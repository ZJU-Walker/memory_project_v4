"""Tests for the prompt->top-camera attention diagnostic.

The span extraction is the part that can silently lie (a mis-sliced span averages the wrong
rows into every metric), so most tests target the ways the sentencepiece layout could break.
"""

# ruff: noqa: SLF001 - the private scale/header helpers are part of the contract under test.

import numpy as np
import pytest

from openpi.diagnostics import v33_prompt_attention as pa


def _pieces(instruction: tuple[str, ...] = ("▁find", "▁the", "▁banana")):
    return ["<bos>", "▁Task", ":", *instruction, ",", "▁State", ":", "▁12", "3", "▁45", ";", "\n"]


def test_prompt_spans_locates_instruction_and_state():
    pieces = _pieces()
    spans = pa.prompt_spans(pieces)
    assert [pieces[i] for i in spans["instruction"]] == ["▁find", "▁the", "▁banana"]
    assert [pieces[i] for i in spans["state"]] == ["▁12", "3", "▁45"]


def test_prompt_spans_handles_merged_colon_pieces():
    pieces = ["<bos>", "▁Task:", "▁find", "▁it", ",", "▁State:", "▁7", ";"]
    spans = pa.prompt_spans(pieces)
    assert [pieces[i] for i in spans["instruction"]] == ["▁find", "▁it"]
    assert [pieces[i] for i in spans["state"]] == ["▁7"]


def test_prompt_spans_strips_the_trailing_comma_only():
    spans = pa.prompt_spans(_pieces(("▁grey", "▁pepper", "▁box")))
    assert len(spans["instruction"]) == 3  # the "," between instruction and State is not a word


def test_prompt_spans_rejects_a_prompt_without_state():
    with pytest.raises(ValueError, match="State"):
        pa.prompt_spans(["<bos>", "▁Task", ":", "▁find", "▁it", ";"])


def test_prompt_spans_rejects_an_empty_instruction():
    with pytest.raises(ValueError, match="degenerate"):
        pa.prompt_spans(["<bos>", "▁Task", ":", ",", "▁State", ":", "▁1", ";"])


def test_prompt_spans_state_ends_at_the_semicolon():
    pieces = [*_pieces(), "extra", "junk"]
    spans = pa.prompt_spans(pieces)
    assert [pieces[i] for i in spans["state"]] == ["▁12", "3", "▁45"]


def test_span_mask_round_trips_indices():
    mask = pa.span_mask(np.array([1, 3]), 5)
    assert mask.tolist() == [False, True, False, True, False]
    assert mask.sum() == 2


def test_map_js_is_zero_for_identical_shapes_and_positive_for_moved_mass():
    a = np.zeros(256)
    a[10] = 0.4  # mass 0.4 of the row lands on the top camera
    b = a * 0.1  # same SHAPE, much less mass
    assert pa.map_js(a, b) == pytest.approx(0.0, abs=1e-12)
    c = np.zeros(256)
    c[200] = 0.4
    assert pa.map_js(a, c) > 0.5


def test_renormalized_entropy_bounds():
    peaked = np.zeros(256)
    peaked[0] = 1.0
    assert pa.renormalized_entropy(peaked) == pytest.approx(0.0, abs=1e-6)
    assert pa.renormalized_entropy(np.ones(256)) == pytest.approx(np.log(256), abs=1e-6)


def test_side_corrected_steer_is_positive_when_attention_follows_the_instruction():
    # left target: TRUE more left than CF -> positive; right target: TRUE more right -> positive
    assert pa.side_corrected_steer(0.6, 0.4, "left") == pytest.approx(0.2)
    assert pa.side_corrected_steer(0.3, 0.5, "right") == pytest.approx(0.2)
    assert pa.side_corrected_steer(0.4, 0.6, "left") == pytest.approx(-0.2)
    with pytest.raises(ValueError, match="side"):
        pa.side_corrected_steer(0.5, 0.5, "middle")


def test_layer_grid_frame_shape_pads_the_last_row():
    rng = np.random.default_rng(1)
    image = rng.integers(0, 255, size=(224, 224, 3), dtype=np.uint8)
    for layers, rows in ((18, 3), (17, 3), (6, 1)):
        maps = rng.random((layers, 256)) * 0.01
        frame = pa.layer_grid_frame(image, maps, [f"L{i}" for i in range(layers)], "label")
        assert frame.shape == (rows * 224 + pa._HEADER, pa._LAYER_GRID_COLUMNS * 224, 3)
        assert frame.dtype == np.uint8


def test_layer_grid_frame_rejects_mismatched_texts():
    image = np.zeros((224, 224, 3), dtype=np.uint8)
    with pytest.raises(ValueError, match="layer maps"):
        pa.layer_grid_frame(image, np.zeros((4, 256)), ["only", "two"], "label")


def test_options_resolve_the_assets_dir_override(tmp_path):
    options = pa.Options(checkpoint="c", dataset_root="d", output_dir="o", assets_dir=tmp_path)
    assert options.assets_dir == tmp_path.resolve()
    assert pa.Options(checkpoint="c", dataset_root="d", output_dir="o").assets_dir is None


def test_options_reject_a_degenerate_view_scale():
    with pytest.raises(ValueError, match="view_scale"):
        pa.Options(checkpoint="c", dataset_root="d", output_dir="o", view_scale=0)


def test_optional_pathway_scalars_reads_a_finetuned_checkpoint():
    raw = {
        "write_query_conditioner": {"output_proj": {"kernel": {"value": np.full((2, 2), 3.0)}}},
        "memory_gate": {"value": np.array([3.0, 4.0])},
    }
    scalars = pa.optional_pathway_scalars(raw)
    assert scalars["memory_gate_norm"] == pytest.approx(5.0)
    assert scalars["conditioner_output_proj_norm"] == pytest.approx(6.0)


def test_optional_pathway_scalars_tolerates_a_base_checkpoint():
    """pi05_base has no memory params at all; the prompt diagnostic must still run."""
    scalars = pa.optional_pathway_scalars({"PaliGemma": {}})
    assert scalars == {"conditioner_output_proj_norm": None, "memory_gate_norm": None}


def test_optional_pathway_scalars_survives_the_runner_monkeypatch(monkeypatch):
    """Regression: the runner rebinds _wa.pathway_scalars to this very function for the
    duration of loading. Resolving the delegate dynamically recursed until RecursionError."""
    monkeypatch.setattr(pa._wa, "pathway_scalars", pa.optional_pathway_scalars)
    assert pa.optional_pathway_scalars({"PaliGemma": {}})["memory_gate_norm"] is None
    raw = {
        "write_query_conditioner": {"output_proj": {"kernel": {"value": np.zeros((2, 2))}}},
        "memory_gate": {"value": np.array([3.0, 4.0])},
    }
    assert pa.optional_pathway_scalars(raw)["memory_gate_norm"] == pytest.approx(5.0)


def _plan(episode: int, prompt: str, side: str):
    return pa._wa._EpisodePlan(
        episode=episode,
        prompt=prompt,
        counterfactual="other",
        side=side,
        evidence=(0, 10),
        memory=(20, 30),
        length=31,
    )


def _override_options(**kwargs):
    return pa.Options(checkpoint="c", dataset_root="d", output_dir="o", **kwargs)


def test_apply_prompt_overrides_replaces_instructions_but_keeps_sides():
    plans = [_plan(30, "find the grey pepper box", "left"), _plan(45, "find the grey pepper box", "right")]
    updated = pa.apply_prompt_overrides(plans, _override_options(prompt_override="find grey box"))
    assert [p.prompt for p in updated] == ["find grey box", "find grey box"]
    assert [p.side for p in updated] == ["left", "right"]  # ground truth untouched
    assert [p.counterfactual for p in updated] == ["other", "other"]  # CF left alone
    assert [p.episode for p in updated] == [30, 45]


def test_apply_prompt_overrides_is_a_noop_without_overrides():
    plans = [_plan(0, "find the banana", "left")]
    assert pa.apply_prompt_overrides(plans, _override_options()) is plans


def test_apply_prompt_overrides_can_replace_the_counterfactual():
    plans = [_plan(0, "find the banana", "left")]
    updated = pa.apply_prompt_overrides(plans, _override_options(counterfactual_override="find grey box"))
    assert updated[0].prompt == "find the banana"
    assert updated[0].counterfactual == "find grey box"


def test_apply_prompt_overrides_rejects_a_collapsed_contrast():
    """TRUE == CF would report a guaranteed zero instruction effect as though it were data."""
    plans = [_plan(0, "find the banana", "left")]
    with pytest.raises(ValueError, match="identical"):
        pa.apply_prompt_overrides(plans, _override_options(prompt_override="other"))


def test_graft_fresh_params_adds_only_missing_subtrees():
    fresh = {
        "PaliGemma": {"llm": {"w": np.zeros(2)}},
        "memory": {"w_k": {"kernel": np.ones(3)}},
        "memory_gate": np.ones(4),
    }
    got = {"PaliGemma": {"llm": {"w": np.full(2, 7.0)}}}
    grafted = pa.graft_fresh_params(fresh, got)
    assert set(grafted) == {"PaliGemma", "memory", "memory_gate"}
    # checkpoint values win where present
    assert grafted["PaliGemma"]["llm"]["w"].tolist() == [7.0, 7.0]
    # missing subtrees come from the fresh init
    assert grafted["memory"]["w_k"]["kernel"].tolist() == [1.0, 1.0, 1.0]


def test_graft_fresh_params_leaves_a_complete_checkpoint_unchanged():
    fresh = {"a": {"x": np.zeros(2)}, "b": np.zeros(2)}
    got = {"a": {"x": np.ones(2)}, "b": np.ones(2)}
    grafted = pa.graft_fresh_params(fresh, got)
    assert grafted["a"]["x"].tolist() == [1.0, 1.0]
    assert grafted["b"].tolist() == [1.0, 1.0]


def test_signed_diff_frame_colors_gains_red_and_losses_blue():
    image = np.full((224, 224, 3), 128, dtype=np.uint8)
    true_values = np.zeros(256)
    cf_values = np.zeros(256)
    true_values[0] = 0.5  # top-left patch: TRUE gained
    cf_values[255] = 0.5  # bottom-right patch: TRUE lost
    frame = pa.signed_diff_frame(image, true_values, cf_values, "label")
    assert frame.shape == (224 + pa._HEADER, 224, 3)
    top_left = frame[pa._HEADER + 3, 3].astype(int)
    bottom_right = frame[-3, -3].astype(int)
    assert top_left[0] > top_left[2]  # red channel dominates where TRUE gained
    assert bottom_right[2] > bottom_right[0]  # blue channel dominates where TRUE lost


def test_signed_diff_frame_rejects_wrong_token_count():
    image = np.zeros((224, 224, 3), dtype=np.uint8)
    with pytest.raises(ValueError, match="256 token values"):
        pa.signed_diff_frame(image, np.zeros(255), np.zeros(256), "label")


def test_options_reject_simultaneous_layer_and_head_sweep():
    with pytest.raises(ValueError, match="one axis at a time"):
        pa.Options(checkpoint="c", dataset_root="d", output_dir="o", layer=-1, head=-1)


def test_single_view_frame_matches_any_image_size():
    rng = np.random.default_rng(2)
    image = rng.integers(0, 255, size=(448, 448, 3), dtype=np.uint8)
    frame = pa.single_view_frame(image, rng.random(256) * 0.01, "ep0 f10 evidence top=13%")
    assert frame.shape == (448 + pa._HEADER, 448, 3)
    assert frame.dtype == np.uint8


def test_single_view_frame_rejects_wrong_token_count():
    image = np.zeros((224, 224, 3), dtype=np.uint8)
    with pytest.raises(ValueError, match="256 token values"):
        pa.single_view_frame(image, np.zeros(255), "label")


def test_single_view_from_npz_requires_layer_for_sweep_arrays(tmp_path):
    npz_path = tmp_path / "episode_000_maps.npz"
    np.savez(npz_path, frames=np.arange(3), instruction_true=np.zeros((3, 18, 256), dtype=np.float16))
    with pytest.raises(ValueError, match="layer sweep"):
        pa.single_view_from_npz(npz_path, tmp_path, 0, tmp_path / "out.mp4")


def test_single_view_from_npz_rejects_layer_for_single_layer_arrays(tmp_path):
    npz_path = tmp_path / "episode_000_maps.npz"
    np.savez(npz_path, frames=np.arange(3), instruction_true=np.zeros((3, 256), dtype=np.float16))
    with pytest.raises(ValueError, match="layer-sweep"):
        pa.single_view_from_npz(npz_path, tmp_path, 0, tmp_path / "out.mp4", layer=8)


def test_prompt_grid_frame_shape_and_dtype():
    rng = np.random.default_rng(0)
    image = rng.integers(0, 255, size=(224, 224, 3), dtype=np.uint8)
    span_maps = {
        span: {"true": rng.random(256) * 0.01, "cf": rng.random(256) * 0.01}
        for span in pa.SPAN_NAMES
    }
    scales = {}
    for span in pa.SPAN_NAMES:
        scales[span] = pa._video_scale([span_maps[span]["true"], span_maps[span]["cf"]])
        scales[f"{span}_diff"] = pa._video_scale([np.abs(span_maps[span]["true"] - span_maps[span]["cf"])])
    frame = pa.prompt_grid_frame(image, span_maps, scales, {}, "label")
    assert frame.shape == (2 * 224 + pa._HEADER, 4 * 224, 3)
    assert frame.dtype == np.uint8
