"""CPU-efficient replay of the v3.3 memory write/read interface.

This diagnostic measures the two quantities needed to reason about the current memory
mechanism without paying for the counterfactual prompt, attention maps, videos, or VLM layers
after the memory interface:

* the fast-weight writer gradient norm before ``TitansMemory.write`` clips it; and
* the RMS scale of the layer-8 residual stream, raw retrieval, and gated retrieval.

The memory state is still replayed faithfully at the training write cadence. Every selected
frame runs one true-prompt ``v32_memory_interface_step`` and commits its resulting 16 write
tokens before advancing to the next frame.
"""

# ruff: noqa: SLF001, I001 - pyarrow must load before the openpi/JAX stack on iris, and this
# intentionally reuses the v3.3 diagnostic's private episode/data/checkpoint implementation.

from __future__ import annotations

import pyarrow.parquet as pq

from collections.abc import Sequence
import dataclasses
import json
import math
from pathlib import Path
import time
from typing import Any

import jax
import jax.numpy as jnp
import numpy as np

from openpi.diagnostics import v33_writer_attention as _attention
from openpi.diagnostics import writer_contribution as _wc
from openpi.shared import nnx_utils

SCHEMA_VERSION = "openpi.v33.memory_interface.v1"
_EPS = 1e-12
_PHASES = ("approach", "evidence", "retention", "waiting")
_SCALE_KEYS = (
    "h8_all_rms",
    "h8_valid_rms",
    "h8_valid_token_count",
    "h8_image_rms",
    "h8_context_valid_rms",
    "h8_top_rms",
    "retrieved_rms",
    "memory_token_rms",
)


@dataclasses.dataclass(frozen=True)
class Options:
    checkpoint: Path
    dataset_root: Path
    output_dir: Path
    config: str = "pi05_yam_mem_v33"
    # Empty selects one usable episode for each (instruction, final side) cell.
    episode_indices: tuple[int, ...] = ()
    stride: int | None = None
    progress_every: int = 5

    def __post_init__(self) -> None:
        for name in ("checkpoint", "dataset_root", "output_dir"):
            object.__setattr__(self, name, Path(getattr(self, name)).expanduser().resolve())
        object.__setattr__(self, "episode_indices", tuple(self.episode_indices))
        if self.stride is not None and self.stride <= 0:
            raise ValueError("stride must be positive")
        if self.progress_every <= 0:
            raise ValueError("progress_every must be positive")


def _phase(raw_frame: int, plan: _attention._EpisodePlan) -> str:
    if plan.evidence[0] <= raw_frame <= plan.evidence[1]:
        return "evidence"
    if raw_frame >= plan.memory[0]:
        return "waiting"
    if raw_frame > plan.evidence[1]:
        return "retention"
    return "approach"


def _scale_statistics(rows: list[dict[str, Any]]) -> dict[str, float | int | None]:
    """Compute c on carried reads, falling back only when the selection is one frame."""
    carried_rows = [row for row in rows if row["writes_before"] > 0]
    selected = carried_rows or rows
    result = _attention.retrieval_scale_statistics(
        np.asarray([row["h8_valid_rms"] for row in selected]),
        np.asarray([row["h8_valid_token_count"] for row in selected]),
        np.asarray([row["h8_image_rms"] for row in selected]),
        np.asarray([row["h8_context_valid_rms"] for row in selected]),
        np.asarray([row["retrieved_rms"] for row in selected]),
        np.asarray([row["memory_token_rms"] for row in selected]),
    )
    result["retrieval_scale_carried_only"] = bool(carried_rows)
    return result


def _phase_table(rows: list[dict[str, Any]], max_grad_norm: float) -> dict[str, dict[str, Any]]:
    table: dict[str, dict[str, Any]] = {}
    for phase in _PHASES:
        phase_rows = [row for row in rows if row["phase"] == phase]
        if not phase_rows:
            continue
        table[phase] = {
            "frames": len(phase_rows),
            **_attention.writer_clip_statistics(
                np.asarray([row["write_grad_norm_preclip"] for row in phase_rows]), max_grad_norm
            ),
            **_scale_statistics(phase_rows),
        }
    return table


def padded_stream_schedule(
    lengths: Sequence[int],
) -> tuple[tuple[tuple[int, ...], tuple[bool, ...]], ...]:
    """Return per-call source indices and activity masks for independently padded streams.

    A finished stream repeats its final source item so every compiled call keeps one static
    batch shape. Its output is ignored; recurrent state remains independent across batch rows.
    """
    stream_lengths = tuple(int(length) for length in lengths)
    if not stream_lengths or any(length <= 0 for length in stream_lengths):
        raise ValueError(f"stream lengths must be non-empty and positive, got {stream_lengths}")
    return tuple(
        (
            tuple(min(step, length - 1) for length in stream_lengths),
            tuple(step < length for length in stream_lengths),
        )
        for step in range(max(stream_lengths))
    )


def _as_batch_vector(output: dict[str, Any], key: str, batch_size: int) -> np.ndarray:
    value = np.asarray(output[key])
    if value.size != batch_size:
        raise ValueError(
            f"memory-interface output {key!r} must have one scalar per batch row "
            f"(B={batch_size}), got {value.shape}"
        )
    return value.reshape(batch_size)


def _batch_observations(observations: Sequence[Any]) -> Any:
    if not observations:
        raise ValueError("cannot batch an empty observation sequence")
    return jax.tree.map(lambda *values: jnp.concatenate(values, axis=0), *observations)


class V33MemoryInterfaceRunner(_attention.V33WriterAttentionRunner):
    """Replay only the layer-8 memory interface and the real recurrent write state."""

    def __init__(self, options: Options):
        # The parent owns the tested checkpoint restoration, transforms, prompt construction,
        # and memory.write setup. Its query-attention callable is constructed but never run.
        super().__init__(
            _attention.Options(
                checkpoint=options.checkpoint,
                dataset_root=options.dataset_root,
                output_dir=options.output_dir,
                config=options.config,
                episode_indices=options.episode_indices,
                stride=options.stride,
            )
        )
        self.options = options
        self._interface = nnx_utils.module_jit(self.model.v32_memory_interface_step)

    def _replay_interfaces_batched(
        self,
        plans: list[_attention._EpisodePlan],
        tasks: dict[int, str],
    ) -> tuple[list[list[dict[str, Any]]], list[float], float]:
        columns = ["image", "left_wrist_image", "right_wrist_image", "state", "frame_index", "task_index"]
        sources = _wc._load_lerobot_sources(self.options.dataset_root, [plan.episode for plan in plans])
        selected_by_episode: list[list[dict[str, Any]]] = []
        for plan, source in zip(plans, sources, strict=True):
            rows = pq.read_table(source.path, columns=columns).to_pylist()
            selected = [
                row
                for row in rows
                if int(row["frame_index"]) % self.stride == 0
                and int(row["frame_index"]) <= plan.memory[1]
            ]
            if not selected:
                raise ValueError(f"episode {plan.episode}: no frames on the stride grid before the wait end")
            selected_by_episode.append(selected)

        batch_size = len(plans)
        schedule = padded_stream_schedule([len(rows) for rows in selected_by_episode])
        memory_state = self.model.memory.init_state(batch_size)
        frames_by_episode: list[list[dict[str, Any]]] = [[] for _ in plans]
        completed_elapsed: list[float | None] = [None for _ in plans]
        final_observations: list[Any | None] = [None for _ in plans]
        started = time.monotonic()
        print(
            f"batched replay B={batch_size}: {[len(rows) for rows in selected_by_episode]} real frames, "
            f"{len(schedule)} interface/write calls",
            flush=True,
        )
        for step, (source_indices, active) in enumerate(schedule):
            if step == 0 or step % self.options.progress_every == 0:
                suffix = " (first call includes JAX compilation)" if step == 0 else ""
                print(
                    f"  batch call {step + 1}/{len(schedule)} active={sum(active)}/{batch_size}{suffix}",
                    flush=True,
                )

            observations = []
            for episode_index, (plan, source_index, is_active) in enumerate(
                zip(plans, source_indices, active, strict=True)
            ):
                if is_active:
                    row = selected_by_episode[episode_index][source_index]
                    raw_frame = int(row["frame_index"])
                    observation, _ = self._observation(row, raw_frame, plan.prompt)
                    if source_index + 1 == len(selected_by_episode[episode_index]):
                        final_observations[episode_index] = observation
                else:
                    observation = final_observations[episode_index]
                    if observation is None:
                        raise AssertionError("finished stream has no cached final observation")
                observations.append(observation)

            output = self._interface(_batch_observations(observations), memory_state)
            next_memory_state, write_aux = self._write(memory_state, output["write_tokens"])
            grad_norms = _as_batch_vector(write_aux, "grad_norm", batch_size)
            aux_vectors = {
                key: _as_batch_vector(write_aux, key, batch_size)
                for key in ("surprise", "theta", "eta", "alpha")
            }
            scale_vectors = {key: _as_batch_vector(output, key, batch_size) for key in _SCALE_KEYS}

            for episode_index, (plan, source_index, is_active) in enumerate(
                zip(plans, source_indices, active, strict=True)
            ):
                if not is_active:
                    continue
                row = selected_by_episode[episode_index][source_index]
                raw_frame = int(row["frame_index"])
                grad_norm = float(grad_norms[episode_index])
                scalar_values = {key: float(values[episode_index]) for key, values in scale_vectors.items()}
                h8_valid_rms = scalar_values["h8_valid_rms"]
                retrieved_rms = scalar_values["retrieved_rms"]
                memory_token_rms = scalar_values["memory_token_rms"]
                episode_frames = frames_by_episode[episode_index]
                episode_frames.append(
                    {
                        "frame": raw_frame,
                        "writes_before": len(episode_frames),
                        "phase": _phase(raw_frame, plan),
                        "task": tasks[int(row["task_index"])],
                        "write_grad_norm_preclip": grad_norm,
                        "write_clip_factor": min(1.0, self.max_grad_norm / (grad_norm + _EPS)),
                        "write_clip_saturated": grad_norm > self.max_grad_norm,
                        "write_surprise": float(aux_vectors["surprise"][episode_index]),
                        "write_theta": float(aux_vectors["theta"][episode_index]),
                        "write_eta": float(aux_vectors["eta"][episode_index]),
                        "write_alpha": float(aux_vectors["alpha"][episode_index]),
                        **scalar_values,
                        "h8_valid_token_count": round(scalar_values["h8_valid_token_count"]),
                        "retrieval_match_c": h8_valid_rms / retrieved_rms if retrieved_rms > _EPS else None,
                        "memory_token_to_h8_ratio": (
                            memory_token_rms / h8_valid_rms if h8_valid_rms > _EPS else None
                        ),
                    }
                )
                if source_index + 1 == len(selected_by_episode[episode_index]):
                    completed_elapsed[episode_index] = time.monotonic() - started
            memory_state = next_memory_state

            if (step + 1) % self.options.progress_every == 0 or step + 1 == len(schedule):
                elapsed = time.monotonic() - started
                real_done = sum(len(frames) for frames in frames_by_episode)
                real_total = sum(len(rows) for rows in selected_by_episode)
                print(
                    f"  completed call {step + 1}/{len(schedule)}, real frames {real_done}/{real_total} "
                    f"({elapsed:.1f}s elapsed, {elapsed / (step + 1):.2f}s/call including compile)",
                    flush=True,
                )

        elapsed = time.monotonic() - started
        return frames_by_episode, [float(value if value is not None else elapsed) for value in completed_elapsed], elapsed

    def run(self) -> dict[str, Any]:
        print(f"pathway scalars: {self.scalars}", flush=True)
        tasks = _attention._read_tasks(self.options.dataset_root)
        plans = _attention._plan_episodes(
            _attention.Options(
                checkpoint=self.options.checkpoint,
                dataset_root=self.options.dataset_root,
                output_dir=self.options.output_dir,
                config=self.options.config,
                episode_indices=self.options.episode_indices,
                stride=self.options.stride,
            ),
            self.data_config,
        )
        print(
            f"replaying {len(plans)} episodes: {[(plan.episode, plan.prompt, plan.side) for plan in plans]}",
            flush=True,
        )
        self.options.output_dir.mkdir(parents=True)

        report: dict[str, Any] = {
            "schema": SCHEMA_VERSION,
            "checkpoint": str(self.options.checkpoint),
            "dataset_root": str(self.options.dataset_root),
            "config": self.options.config,
            "stride": self.stride,
            "inner_clip_max_grad_norm": self.max_grad_norm,
            "pathway_scalars": self.scalars,
            "episodes": [],
        }
        frames_by_episode, completed_elapsed, batch_elapsed = self._replay_interfaces_batched(plans, tasks)
        report["batch_elapsed_seconds"] = batch_elapsed
        report["interface_write_call_count"] = max(len(frames) for frames in frames_by_episode)
        all_frames: list[dict[str, Any]] = []
        for plan, frames, elapsed in zip(plans, frames_by_episode, completed_elapsed, strict=True):
            report["episodes"].append(
                {
                    "episode": plan.episode,
                    "prompt": plan.prompt,
                    "side": plan.side,
                    "evidence": list(plan.evidence),
                    "memory": list(plan.memory),
                    "elapsed_seconds": elapsed,
                    "phase_table": _phase_table(frames, self.max_grad_norm),
                    "writer_clip_summary": _attention.writer_clip_statistics(
                        np.asarray([frame["write_grad_norm_preclip"] for frame in frames]), self.max_grad_norm
                    ),
                    "retrieval_scale_summary": _scale_statistics(frames),
                    "frames": frames,
                }
            )
            all_frames.extend(frames)

        report["frame_count"] = len(all_frames)
        report["phase_table"] = _phase_table(all_frames, self.max_grad_norm)
        report["writer_clip_summary"] = _attention.writer_clip_statistics(
            np.asarray([frame["write_grad_norm_preclip"] for frame in all_frames]), self.max_grad_norm
        )
        report["retrieval_scale_summary"] = _scale_statistics(all_frames)
        summary_path = self.options.output_dir / "summary.json"
        summary_path.write_text(json.dumps(report, indent=2))
        self._print_summary(report)
        print(f"wrote {summary_path}", flush=True)
        return report

    def _print_summary(self, report: dict[str, Any]) -> None:
        clip_rows = {
            "all": {"frames": report["frame_count"], **report["writer_clip_summary"]},
            **report["phase_table"],
        }
        print(
            f"\ninner writer clip (threshold={self.max_grad_norm:g}; gradient norms are pre-clip)\n"
            f"{'phase':>10} {'frames':>7} {'g_min':>10} {'g_p50':>10} {'g_p95':>10} "
            f"{'g_max':>10} {'sat_frac':>9} {'clip_p50':>10}",
            flush=True,
        )
        for phase, row in clip_rows.items():
            print(
                f"{phase:>10} {row['frames']:>7} {row['write_grad_norm_preclip_min']:>10.3g} "
                f"{row['write_grad_norm_preclip_median']:>10.3g} "
                f"{row['write_grad_norm_preclip_p95']:>10.3g} "
                f"{row['write_grad_norm_preclip_max']:>10.3g} "
                f"{row['write_clip_saturation_fraction']:>9.3f} "
                f"{row['write_clip_factor_median']:>10.3g}",
                flush=True,
            )

        scale_rows = {"all": report["retrieval_scale_summary"], **report["phase_table"]}
        print(
            "\nread-injection scale (initial pre-write frame excluded when carried reads exist)\n"
            f"{'phase':>10} {'used':>7} {'h8_p50':>10} {'ret_p50':>10} {'inj_p50':>10} "
            f"{'c_p05':>10} {'c_p50':>10} {'c_p95':>10} {'c_energy':>10} {'c_extra':>10}",
            flush=True,
        )
        for phase, row in scale_rows.items():
            values = [
                row["retrieval_match_c_p05"],
                row["retrieval_match_c_median"],
                row["retrieval_match_c_p95"],
                row["retrieval_match_c_energy"],
                row["gated_match_c_extra_median"],
            ]
            printable = [value if value is not None else math.nan for value in values]
            print(
                f"{phase:>10} {row['retrieval_scale_frame_count']:>7} "
                f"{row['h8_valid_rms_median']:>10.3g} {row['retrieved_rms_median']:>10.3g} "
                f"{row['memory_token_rms_median']:>10.3g} "
                f"{printable[0]:>10.3g} {printable[1]:>10.3g} {printable[2]:>10.3g} "
                f"{printable[3]:>10.3g} {printable[4]:>10.3g}",
                flush=True,
            )
