import pytest

from openpi.diagnostics.v33_memory_interface import padded_stream_schedule


def test_padded_stream_schedule_repeats_last_and_marks_inactive() -> None:
    assert padded_stream_schedule([2, 4]) == (
        ((0, 0), (True, True)),
        ((1, 1), (True, True)),
        ((1, 2), (False, True)),
        ((1, 3), (False, True)),
    )


@pytest.mark.parametrize("lengths", [[], [0], [2, -1]])
def test_padded_stream_schedule_rejects_empty_streams(lengths: list[int]) -> None:
    with pytest.raises(ValueError, match="non-empty and positive"):
        padded_stream_schedule(lengths)
