"""Where does the TASK PROMPT look at layer 8? Instruction-row attention over the top camera.

Motivation: every v3.x conditioner steers the memory writer with hidden states of the prompt
span, so the first question is what the VLM's OWN attention already does there -- do the
instruction words ("find the banana") attend to the instructed bin at the layer the memory
taps, and does swapping the instruction move that attention? If the backbone already routes
instruction rows to the right patches, a conditioner only has to expose that; if it does not,
no residual query trick can read a signal that is not there.

The pi05 prompt is one string, ``Task: {instruction}, State: {state digits};``, so "the prompt"
mixes two very different populations of rows. This diagnostic splits them by sentencepiece
pieces and reports them separately:

* ``instruction`` rows -- the task words. Their attention is the candidate conditioning signal.
* ``state`` rows -- the discretized proprioception digits. Their attention is the contamination
  baseline: whatever the instruction rows do that the state rows also do is not task routing.

Per episode it renders one MP4 (rows: instruction / state; columns: camera, TRUE prompt,
counterfactual prompt, |TRUE-CF|), saves the per-token maps as NPZ, and writes a summary JSON
with per-phase masses and TRUE-vs-CF divergences. Nothing here touches the memory: the maps
come from a plain image+prompt prefix pass, which is bit-identical to inference for blocks
``0..memory_layer`` because memory tokens are inserted only after that block.
"""

# ruff: noqa: SLF001, I001 - deliberately reuses the v3.2/v3.3 replay machinery; the
# pyarrow-before-openpi import order is load-bearing (see v33_writer_attention for why).

from __future__ import annotations

import pyarrow.parquet as pq

import dataclasses
import json
from pathlib import Path
import tempfile
import time
from typing import Any

import cv2
from flax import nnx
import jax
import numpy as np

from openpi.diagnostics import token_heatmap
from openpi.diagnostics import v33_writer_attention as _wa
from openpi.diagnostics import writer_contribution as _wc
from openpi.models import model as _model
from openpi.shared import nnx_utils
from openpi.training import config as _config

SCHEMA_VERSION = "openpi.v33.prompt_attention.v1"
_EPS = 1e-12

SPAN_NAMES = ("instruction", "state")

# Bound at import, before any runner rebinds the module attribute (see below).
_PATHWAY_SCALARS = _wa.pathway_scalars
_RESTORE_PARAMS = _model.restore_params


def graft_fresh_params(fresh: Any, got: Any) -> Any:
    """Fill parameters the checkpoint lacks from a freshly initialized parameter tree.

    An untrained ``pi05_base`` checkpoint has no memory subtree at all (no ``memory``,
    ``memory_gate``, query compressors, conditioner, or probe head), so the strict structure
    check in ``BaseModelConfig.load`` rejects it. This diagnostic reads ONLY the VLM prefix
    -- blocks 0..memory_layer of the PaliGemma tower -- and never invokes the memory, so the
    grafted values are inert placeholders that make the model constructible; they are never
    read on this code path.

    Grafting only ADDS subtrees that are missing. Every parameter the checkpoint does provide
    is taken from the checkpoint, so a finetuned checkpoint is returned unchanged.
    """
    if not isinstance(fresh, dict) or not isinstance(got, dict):
        return got
    grafted = dict(got)
    for key, fresh_child in fresh.items():
        grafted[key] = graft_fresh_params(fresh_child, got[key]) if key in got else fresh_child
    return grafted


def optional_pathway_scalars(raw_params: Any) -> dict[str, float | None]:
    """:func:`_wa.pathway_scalars`, but ``None`` where a checkpoint lacks the pathway.

    An untrained ``pi05_base`` checkpoint has no memory or conditioner parameters at all. The
    writer diagnostics rightly refuse such a checkpoint; this one only reads the VLM prefix, so
    the scalars are context to report, not a precondition.

    Binds the original function at import time: the runner temporarily rebinds the module
    attribute to THIS function, so resolving it dynamically would recurse forever.
    """
    try:
        return dict(_PATHWAY_SCALARS(raw_params))
    except KeyError:
        return {"conditioner_output_proj_norm": None, "memory_gate_norm": None}


@dataclasses.dataclass(frozen=True)
class Options(_wa.Options):
    # Gemma block whose attention is rendered. None = the model's memory_layer, i.e. exactly
    # the block whose output the memory reads and writes. -1 = sweep every block in one pass
    # (LayerSweepRunner): per-layer grid videos and a per-layer summary instead of the
    # single-layer TRUE/CF/diff video.
    layer: int | None = None
    # Single attention head; None = head mean. A routing head can be diluted by sink heads in
    # the mean, so -1 sweeps every head of ONE layer (HeadSweepRunner) -- the honest follow-up
    # when the mean looks flat. Cannot be combined with layer=-1.
    head: int | None = None

    # Sweep rendering: False writes the compact grid videos (one tile per layer/head), True
    # writes one SINGLE-VIEW video per slice instead -- the plain "camera + this layer's
    # instruction attention" clip, which is what you want when reading one layer closely.
    single_view: bool = False
    # Upscale factor for single-view frames (the model image is only 224px).
    view_scale: int = 2
    # Replace the TRUE instruction with this exact string on every replayed episode, keeping
    # the dataset's target-side labels. Use it to test wording sensitivity: does the routing
    # survive a paraphrase ("find grey box" for "find the grey pepper box"), or is it keyed to
    # the exact pretrained phrase? Empty keeps each episode's own prompt.
    prompt_override: str = ""
    # Replace the counterfactual instruction likewise. Empty keeps the dataset's other prompt.
    counterfactual_override: str = ""
    # Directory holding the norm stats to preprocess with (the parent of ``<asset_id>/``).
    # Needed for an untrained pi05_base checkpoint, which ships no YAM stats: point it at the
    # FINETUNED checkpoint's assets so both arms of a base-vs-finetuned comparison see
    # identically preprocessed inputs and only the weights differ.
    assets_dir: Path | None = None

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.assets_dir is not None:
            object.__setattr__(self, "assets_dir", Path(self.assets_dir).expanduser().resolve())
        if self.view_scale < 1:
            raise ValueError("view_scale must be at least 1")
        if self.layer is not None and self.layer < -1:
            raise ValueError("layer must be -1 (all layers), None (memory_layer), or a block index")
        if self.head is not None and self.head < -1:
            raise ValueError("head must be -1 (all heads), None (head mean), or a head index")
        if self.layer == -1 and self.head == -1:
            raise ValueError("layer=-1 and head=-1 cannot be combined; sweep one axis at a time")


def prompt_spans(pieces: list[str]) -> dict[str, np.ndarray]:
    """Token indices of the instruction words and the state digits inside the prompt pieces.

    The pi05 prefix is ``Task: {instruction}, State: {digits};`` -- sentencepiece renders it
    as ``<bos> ▁Task : ▁find ... , ▁State : ▁12 ... ;``. The markers are structural (the
    instruction is lowercased free text, so it can never contain the capitalized ``State``),
    which makes this split exact rather than heuristic. Raises with the full piece dump when
    the layout assumption breaks, because silently mis-slicing would poison every metric.
    """

    def find(predicate, start: int, what: str) -> int:
        for index in range(start, len(pieces)):
            if predicate(pieces[index]):
                return index
        raise ValueError(f"could not locate {what} in prompt pieces: {pieces}")

    bare = [piece.lstrip("▁") for piece in pieces]
    task = find(lambda p: p.lstrip("▁").startswith("Task"), 0, "'Task'")
    colon1 = task if ":" in pieces[task] else find(lambda p: ":" in p, task + 1, "the colon after 'Task'")
    state = find(lambda p: p.lstrip("▁").startswith("State"), colon1 + 1, "'State'")
    instruction = list(range(colon1 + 1, state))
    while instruction and bare[instruction[-1]] in (",", ""):
        instruction.pop()
    colon2 = state if ":" in pieces[state] else find(lambda p: ":" in p, state + 1, "the colon after 'State'")
    end = next((i for i in range(colon2 + 1, len(pieces)) if ";" in pieces[i]), len(pieces))
    state_span = list(range(colon2 + 1, end))
    if not instruction or not state_span:
        raise ValueError(f"degenerate prompt spans (instruction={instruction}, state={state_span}): {pieces}")
    return {"instruction": np.asarray(instruction, dtype=np.int64), "state": np.asarray(state_span, dtype=np.int64)}


def span_mask(span: np.ndarray, length: int) -> np.ndarray:
    """Boolean [length] mask for a span index array -- the NPZ-friendly ragged representation."""
    mask = np.zeros(length, dtype=bool)
    mask[np.asarray(span, dtype=np.int64)] = True
    return mask


def renormalized_entropy(values: np.ndarray) -> float:
    """Entropy (nats) of a map renormalized over its own mass; max ln(256) ~ 5.55."""
    p = np.asarray(values, dtype=np.float64).ravel()
    p = np.clip(p / max(float(p.sum()), _EPS), _EPS, 1.0)
    return float(-(p * np.log(p)).sum())


def map_js(a: np.ndarray, b: np.ndarray) -> float:
    """JS divergence between two maps, each renormalized over the 256 top-camera patches.

    Renormalization matters: the raw rows are softmaxes over ALL prefix keys, so their top-cam
    slices carry different total mass. JS on the renormalized maps asks "did the SHAPE over the
    image move", which is the conditioning question; the mass change is reported separately.
    """
    p = np.asarray(a, dtype=np.float64).ravel()
    q = np.asarray(b, dtype=np.float64).ravel()
    p = p / max(float(p.sum()), _EPS)
    q = q / max(float(q.sum()), _EPS)
    return float(_wa.js_divergence(p[None], q[None])[0])


def apply_prompt_overrides(plans: list[Any], options: Options) -> list[Any]:
    """Swap the instruction strings on planned episodes, leaving side labels untouched.

    The target side comes from the episode's final subtask label, not from its prompt, so an
    override changes only what the model is told -- the ground truth the steer metric is
    scored against stays the dataset's. Rejects an override that makes TRUE and CF identical,
    which would silently report zero instruction effect as if it were a finding.
    """
    if not options.prompt_override and not options.counterfactual_override:
        return plans
    updated = []
    for plan in plans:
        prompt = options.prompt_override or plan.prompt
        counterfactual = options.counterfactual_override or plan.counterfactual
        if prompt == counterfactual:
            raise ValueError(f"prompt override makes TRUE and CF identical ({prompt!r}); the contrast would vanish")
        updated.append(dataclasses.replace(plan, prompt=prompt, counterfactual=counterfactual))
    return updated


def side_corrected_steer(left_true: float, left_cf: float, side: str) -> float:
    """Positive when the TRUE instruction pulls attention toward ITS target side vs the CF.

    ``left_*`` are left-half attention masses; ``side`` is the TRUE target. The sign
    correction makes episodes with opposite layouts addable: +0.1 always means "the swap moved
    a tenth of the (renormalized) mass toward the instructed bin", never "toward the left".
    """
    if side not in ("left", "right"):
        raise ValueError(f"side must be 'left' or 'right', got {side!r}")
    return (left_true - left_cf) if side == "left" else (left_cf - left_true)


def _video_scale(series: list[np.ndarray]) -> token_heatmap.ColorScale:
    values = np.concatenate([np.asarray(entry, dtype=np.float64).ravel() for entry in series])
    vmax = float(np.percentile(values, 99.0))
    return token_heatmap.ColorScale(
        vmin=0.0,
        vmax=max(vmax, float(_EPS)),
        lower_percentile=0.0,
        upper_percentile=99.0,
        anchor_zero=True,
    )


_HEADER = 28


def prompt_grid_frame(
    image: np.ndarray,
    span_maps: dict[str, dict[str, np.ndarray]],
    scales: dict[str, token_heatmap.ColorScale],
    texts: dict[str, str],
    label: str,
) -> np.ndarray:
    """One composite frame: rows = (instruction, state), columns = (camera, TRUE, CF, |TRUE-CF|).

    ``span_maps[span]`` holds ``true`` and ``cf`` maps of 256 values; ``scales`` carries one
    video-level color scale per span plus ``{span}_diff`` for the difference column, so frames
    stay comparable across the episode.
    """
    rows = []
    for span in SPAN_NAMES:
        true_map = np.asarray(span_maps[span]["true"], dtype=np.float64)
        cf_map = np.asarray(span_maps[span]["cf"], dtype=np.float64)
        tiles = [image.copy()]
        for values, scale in (
            (true_map, scales[span]),
            (cf_map, scales[span]),
            (np.abs(true_map - cf_map), scales[f"{span}_diff"]),
        ):
            overlay, _ = token_heatmap.heatmap_overlay(image, values, scale, scale_mode="video")
            tiles.append(overlay)
        for column, text_key in enumerate((f"{span}_image", f"{span}_true", f"{span}_cf", f"{span}_diff")):
            cv2.putText(
                tiles[column],
                texts.get(text_key, ""),
                (4, 16),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.42,
                (255, 255, 255),
                1,
                cv2.LINE_AA,
            )
        rows.append(np.concatenate(tiles, axis=1))
    grid = np.concatenate(rows, axis=0)
    bar = np.zeros((_HEADER, grid.shape[1], 3), dtype=np.uint8)
    cv2.putText(bar, label[:110], (6, 19), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (245, 245, 245), 1, cv2.LINE_AA)
    return np.concatenate([bar, grid], axis=0)


_LAYER_GRID_COLUMNS = 6


def layer_grid_frame(
    image: np.ndarray,
    layer_maps: np.ndarray,
    tile_texts: list[str],
    label: str,
) -> np.ndarray:
    """One composite frame with one tile per gemma block, v3.2-style normalization.

    Each tile is normalized by ITS OWN per-frame maximum (JET, intensity alpha), because the
    absolute attention scale differs by orders of magnitude across depth -- a shared scale
    would render every early layer black. The stamped text carries the absolute numbers the
    colors deliberately discard. Missing tiles of the last row are left black.
    """
    maps = np.asarray(layer_maps, dtype=np.float64)
    if maps.ndim != 2 or maps.shape[1] != 256 or maps.shape[0] != len(tile_texts):
        raise ValueError(f"layer maps must be [layers, 256] matching texts, got {maps.shape} / {len(tile_texts)}")
    grid_rows = -(-maps.shape[0] // _LAYER_GRID_COLUMNS)
    rows = []
    for row_index in range(grid_rows):
        tiles = []
        for column in range(_LAYER_GRID_COLUMNS):
            index = row_index * _LAYER_GRID_COLUMNS + column
            if index < maps.shape[0]:
                tile = _wa._v32_style_tile(image, maps[index])
                cv2.putText(
                    tile, tile_texts[index], (4, 16), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (255, 255, 255), 1, cv2.LINE_AA
                )
            else:
                tile = np.zeros_like(image)
            tiles.append(tile)
        rows.append(np.concatenate(tiles, axis=1))
    grid = np.concatenate(rows, axis=0)
    bar = np.zeros((_HEADER, grid.shape[1], 3), dtype=np.uint8)
    cv2.putText(bar, label[:130], (6, 19), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (245, 245, 245), 1, cv2.LINE_AA)
    return np.concatenate([bar, grid], axis=0)


def single_view_frame(image: np.ndarray, values: np.ndarray, label: str) -> np.ndarray:
    """One plain tile: the camera image under a per-frame-max JET overlay (v3.2 convention).

    Accepts any image size (the 16x16 token grid is resized to match), so callers can upscale
    the camera frame first for a watchable single-view video. Per-frame max normalization makes
    the SHAPE obvious; the absolute magnitude belongs in ``label`` (e.g. the top-camera mass).
    """
    grid = np.asarray(values, dtype=np.float64)
    if grid.size != token_heatmap.TOKEN_COUNT:
        raise ValueError(f"expected {token_heatmap.TOKEN_COUNT} token values, got {grid.shape}")
    grid = grid.reshape(token_heatmap.TOKEN_GRID_SIZE, token_heatmap.TOKEN_GRID_SIZE)
    height, width = image.shape[:2]
    heat = grid / max(float(grid.max()), _EPS)
    heat_image = cv2.resize(heat.astype(np.float32), (width, height), interpolation=cv2.INTER_NEAREST)
    color = cv2.applyColorMap((heat_image * 255).astype(np.uint8), cv2.COLORMAP_JET)[:, :, ::-1]
    weight = (0.6 * heat_image)[..., None]
    tile = (image.astype(np.float32) * (1 - weight) + color * weight).astype(np.uint8)
    bar = np.zeros((_HEADER, width, 3), dtype=np.uint8)
    cv2.putText(bar, label[: width // 9], (6, 19), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (245, 245, 245), 1, cv2.LINE_AA)
    return np.concatenate([bar, tile], axis=0)


def signed_diff_frame(image: np.ndarray, true_values: np.ndarray, cf_values: np.ndarray, label: str) -> np.ndarray:
    """One tile of the SIGNED instruction effect: red = attention GAINED under the TRUE
    instruction relative to the counterfactual, blue = attention lost.

    This is the panel that isolates the conditioning signal: the large instruction-independent
    baseline (salient objects, sinks, the right-bin anchor) is identical in both encodings and
    cancels exactly, so any color at all is instruction-driven. Normalized by the frame's own
    peak |difference|; the absolute peak belongs in ``label``.
    """
    true_grid = np.asarray(true_values, dtype=np.float64)
    cf_grid = np.asarray(cf_values, dtype=np.float64)
    if true_grid.size != token_heatmap.TOKEN_COUNT or cf_grid.size != token_heatmap.TOKEN_COUNT:
        raise ValueError(f"expected {token_heatmap.TOKEN_COUNT} token values, got {true_grid.shape}/{cf_grid.shape}")
    size = token_heatmap.TOKEN_GRID_SIZE
    diff = (true_grid - cf_grid).reshape(size, size)
    peak = max(float(np.abs(diff).max()), _EPS)
    height, width = image.shape[:2]
    normalized = cv2.resize((diff / peak).astype(np.float32), (width, height), interpolation=cv2.INTER_NEAREST)
    color = np.zeros_like(image)
    color[..., 0] = np.where(normalized > 0, 255, 0)  # red: TRUE gained
    color[..., 2] = np.where(normalized < 0, 255, 0)  # blue: TRUE lost
    weight = (0.6 * np.abs(normalized))[..., None]
    tile = (image.astype(np.float32) * (1 - weight) + color.astype(np.float32) * weight).astype(np.uint8)
    bar = np.zeros((_HEADER, width, 3), dtype=np.uint8)
    cv2.putText(bar, label[: width // 9], (6, 19), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (245, 245, 245), 1, cv2.LINE_AA)
    return np.concatenate([bar, tile], axis=0)


def single_view_from_npz(
    npz_path: Path,
    dataset_root: Path,
    episode: int,
    output_path: Path,
    *,
    span: str = "instruction",
    variant: str = "true",
    layer: int | None = None,
    fps: float = 4.0,
    scale: int = 2,
) -> str:
    """Re-render ONE overlay per frame from a saved maps NPZ -- CPU only, no model, no GPU.

    ``variant`` may be ``true``, ``cf``, or ``diff``: the first two render the plain overlay
    (:func:`single_view_frame`), ``diff`` renders the SIGNED TRUE-minus-CF effect
    (:func:`signed_diff_frame`, red = gained under the true instruction).

    Works on both NPZ generations: single-layer runs store ``{span}_{variant}`` as
    ``[frames, 256]``; sweep runs store ``[frames, slices, 256]`` and then require ``layer``
    (which indexes whatever the sweep axis was -- gemma blocks or attention heads). Phase
    labels are reconstructed from the run's ``summary.json`` episode boundaries when it sits
    next to the NPZ; the top-camera mass needs no summary (each row is a softmax slice, so
    the map's own sum IS the mass).
    """
    npz_path, output_path = Path(npz_path), Path(output_path)
    data = np.load(npz_path)

    def load_stream(name: str) -> np.ndarray:
        if name not in data:
            raise KeyError(f"{npz_path} has no stream {name!r}; available: {sorted(data.keys())}")
        values = np.asarray(data[name], dtype=np.float64)
        if values.ndim == 3:
            if layer is None:
                raise ValueError(f"{npz_path} is a layer sweep ({values.shape[1]} slices); pass layer=")
            return values[:, layer]
        if layer is not None:
            raise ValueError("layer= only applies to layer-sweep NPZs")
        return values

    if variant == "diff":
        maps, cf_maps = load_stream(f"{span}_true"), load_stream(f"{span}_cf")
    else:
        maps, cf_maps = load_stream(f"{span}_{variant}"), None
    frame_indices = np.asarray(data["frames"], dtype=np.int64)

    prompt, cf_prompt, evidence, memory = "", "", None, None
    summary_path = npz_path.parent / "summary.json"
    if summary_path.is_file():
        summary = json.loads(summary_path.read_text())
        entry = next((e for e in summary["episodes"] if e["episode"] == episode), None)
        if entry is not None:
            prompt = entry["counterfactual"] if variant == "cf" else entry["prompt"]
            cf_prompt = entry["counterfactual"]
            evidence, memory = entry["evidence"], entry["memory"]

    def phase_of(frame: int) -> str:
        if evidence is None or memory is None:
            return ""
        if evidence[0] <= frame <= evidence[1]:
            return "evidence"
        if frame >= memory[0]:
            return "waiting"
        return "retention" if frame > evidence[1] else "approach"

    source = _wc._load_lerobot_sources(dataset_root, [episode])[0]
    rows = pq.read_table(source.path, columns=["image", "frame_index"]).to_pylist()
    by_frame = {int(row["frame_index"]): row for row in rows}
    layer_tag = "" if layer is None else f" L{layer}"
    video_frames = []
    for index, frame in enumerate(frame_indices):
        raw = _wc.WriterContributionRunner._decode_inline_image(
            by_frame[int(frame)]["image"], field="image", raw_frame=int(frame)
        )
        model_rgb, _ = token_heatmap.raw_top_camera_to_model_rgb(raw)
        if scale != 1:
            model_rgb = cv2.resize(
                model_rgb, (model_rgb.shape[1] * scale, model_rgb.shape[0] * scale), interpolation=cv2.INTER_LINEAR
            )
        prefix = f"ep{episode} f{int(frame)} {phase_of(int(frame))}{layer_tag}"
        if cf_maps is None:
            label = f"{prefix} top={maps[index].sum():.0%} | {prompt}"
            video_frames.append(single_view_frame(model_rgb, maps[index], label))
        else:
            peak = float(np.abs(maps[index] - cf_maps[index]).max())
            label = f"{prefix} red=TRUE gained, blue=lost, peak={peak:.4f} | TRUE: {prompt} vs CF: {cf_prompt}"
            video_frames.append(signed_diff_frame(model_rgb, maps[index], cf_maps[index], label))
    return token_heatmap.encode_mp4(video_frames, output_path, fps)


class PromptAttentionRunner(_wa.V33WriterAttentionRunner):
    """Replays episodes and records prompt-row attention; reuses the v3.3 loading machinery.

    Unlike the writer diagnostics this one reads ONLY the VLM prefix, so it also runs against
    an untrained ``pi05_base`` checkpoint: the memory/conditioner parameters it lacks are
    grafted at their fresh initialization by ``_align_params`` and never touched on this code
    path. That makes "is instruction routing pretrained or finetuned in?" a direct A/B.
    """

    def __init__(self, options: Options):
        # The base class computes pathway_scalars eagerly and hard-fails on a checkpoint that
        # has no memory parameters. Swap in the tolerant variant just for that call so an
        # untrained pi05_base loads; every other loading step is shared unchanged.
        original = _wa.pathway_scalars
        _wa.pathway_scalars = optional_pathway_scalars
        # Likewise for norm stats. The base class tries `<checkpoint>/assets/<asset_id>` first
        # and falls back to the config's assets dir; for pi05_base neither exists. `assets_dir`
        # names a replacement root, which is presented to the base class as a stitched
        # checkpoint view: `params` and `assets` symlinked from their respective sources. No
        # loading logic is patched, and the real checkpoint directory is never written to.
        init_options = options
        stitched: tempfile.TemporaryDirectory | None = None
        if options.assets_dir is not None:
            stitched = tempfile.TemporaryDirectory(prefix="prompt_attention_ckpt_")
            root = Path(stitched.name)
            (root / "params").symlink_to(options.checkpoint / "params")
            (root / "assets").symlink_to(options.assets_dir)
            init_options = dataclasses.replace(options, checkpoint=root)
        # Finally, the params themselves: a base checkpoint has no memory subtree, which the
        # strict structure check in BaseModelConfig.load rejects. Graft the missing subtrees
        # from a fresh initialization at restore time -- inert here, since only the VLM prefix
        # is ever run. A finetuned checkpoint provides every key and passes through unchanged.
        model_config = _config.get_config(options.config).model

        def restore_with_graft(*args: Any, **kwargs: Any) -> Any:
            restored = _RESTORE_PARAMS(*args, **kwargs)
            if "memory" in restored:  # a finetuned checkpoint: nothing to graft
                return restored
            print("checkpoint has no memory parameters (base model): grafting unused zero placeholders")
            # Shapes only: really initializing the model would allocate a second copy of the
            # 3B backbone (measured: OOM on a 24 GB A5000). The grafted arrays are never read
            # on this code path, so zeros of the right shape/dtype are a sufficient stand-in.
            abstract = nnx.state(nnx.eval_shape(lambda: model_config.create(jax.random.key(0))), nnx.Param)
            fresh = jax.tree.map(lambda leaf: np.zeros(leaf.shape, leaf.dtype), abstract.to_pure_dict())
            return graft_fresh_params(fresh, restored)

        _model.restore_params = restore_with_graft
        try:
            super().__init__(init_options)
        finally:
            _wa.pathway_scalars = original
            _model.restore_params = _RESTORE_PARAMS
            if stitched is not None:
                stitched.cleanup()
        self.options: Options = options
        self._pstep = nnx_utils.module_jit(self.model.prompt_attention_maps, static_argnames=("layer", "head"))
        tokenize = next(
            (
                transform
                for transform in self.data_config.model_transforms.inputs
                if hasattr(transform, "tokenizer") and hasattr(transform.tokenizer, "_paligemma_tokenizer")
            ),
            None,
        )
        if tokenize is None:
            raise ValueError("no tokenize transform with a sentencepiece processor in the model transforms")
        self._sp = tokenize.tokenizer._paligemma_tokenizer

    def _pieces(self, observation) -> tuple[list[str], int]:
        ids = np.asarray(observation.tokenized_prompt[0])
        valid = np.asarray(observation.tokenized_prompt_mask[0]).astype(bool)
        count = int(valid.sum())
        if not (valid[:count].all() and not valid[count:].any()):
            raise ValueError("tokenized prompt padding is not a trailing run; span indices would misalign")
        return [self._sp.id_to_piece(int(token)) for token in ids[:count]], count

    def _variant(self, out: dict[str, Any], observation) -> dict[str, Any]:
        pieces, count = self._pieces(observation)
        spans = prompt_spans(pieces)
        rows = np.asarray(out["prompt_to_top"], dtype=np.float64)[0]  # [max_token_len, 256]
        images_mass = np.asarray(out["prompt_to_images_mass"], dtype=np.float64)[0]
        text_mass = np.asarray(out["prompt_to_text_mass"], dtype=np.float64)[0]
        result: dict[str, Any] = {"pieces": pieces, "count": count, "spans": spans, "rows": rows}
        for span in SPAN_NAMES:
            indices = spans[span]
            mean_map = rows[indices].mean(axis=0)
            result[span] = {
                "map": mean_map,
                # each row is a softmax over all prefix keys; the top-cam slice sum IS the mass
                "top_mass": float(rows[indices].sum(axis=-1).mean()),
                "images_mass": float(images_mass[indices].mean()),
                "text_mass": float(text_mass[indices].mean()),
                "text": "".join(pieces[i] for i in indices).replace("▁", " ").strip(),
            }
        return result

    def _replay(self, plan: _wa._EpisodePlan, tasks: dict[int, str]) -> dict[str, Any]:
        source = _wc._load_lerobot_sources(self.options.dataset_root, [plan.episode])[0]
        columns = ["image", "left_wrist_image", "right_wrist_image", "state", "frame_index", "task_index"]
        rows = pq.read_table(source.path, columns=columns).to_pylist()

        frames: list[dict[str, Any]] = []
        images: list[np.ndarray] = []
        maps: dict[str, list[np.ndarray]] = {f"{span}_{variant}": [] for span in SPAN_NAMES for variant in ("true", "cf")}
        token_maps: dict[str, list[np.ndarray]] = {"true": [], "cf": []}
        token_masks: dict[str, list[np.ndarray]] = {
            f"{name}_{variant}": [] for name in ("valid", *SPAN_NAMES) for variant in ("true", "cf")
        }
        span_texts: dict[str, str] = {}
        started = time.monotonic()
        with self.model.capture_attention():
            for row in rows:
                raw_frame = int(row["frame_index"])
                if raw_frame % self.stride or raw_frame > plan.memory[1]:
                    continue
                observation_true, model_image = self._observation(row, raw_frame, plan.prompt)
                observation_cf, _ = self._observation(row, raw_frame, plan.counterfactual)
                variants = {}
                for variant, observation in (("true", observation_true), ("cf", observation_cf)):
                    out = self._pstep(observation, layer=self.options.layer, head=self.options.head)
                    variants[variant] = self._variant(out, observation)
                    max_len = variants[variant]["rows"].shape[0]
                    token_maps[variant].append(variants[variant]["rows"].astype(np.float16))
                    token_masks[f"valid_{variant}"].append(
                        span_mask(np.arange(variants[variant]["count"]), max_len)
                    )
                    for span in SPAN_NAMES:
                        maps[f"{span}_{variant}"].append(variants[variant][span]["map"].astype(np.float32))
                        token_masks[f"{span}_{variant}"].append(
                            span_mask(variants[variant]["spans"][span], max_len)
                        )
                        span_texts[f"{span}_{variant}"] = variants[variant][span]["text"]

                phase = (
                    "evidence"
                    if plan.evidence[0] <= raw_frame <= plan.evidence[1]
                    else "waiting"
                    if raw_frame >= plan.memory[0]
                    else "retention"
                    if raw_frame > plan.evidence[1]
                    else "approach"
                )
                record: dict[str, Any] = {"frame": raw_frame, "phase": phase, "task": tasks[int(row["task_index"])]}
                for span in SPAN_NAMES:
                    for variant in ("true", "cf"):
                        entry = variants[variant][span]
                        record[f"{span}_top_mass_{variant}"] = entry["top_mass"]
                        record[f"{span}_images_mass_{variant}"] = entry["images_mass"]
                        record[f"{span}_text_mass_{variant}"] = entry["text_mass"]
                        record[f"{span}_left_mass_{variant}"] = _wa.left_half_mass(entry["map"][None])
                    record[f"{span}_js_true_cf"] = map_js(variants["true"][span]["map"], variants["cf"][span]["map"])
                    record[f"{span}_entropy_true"] = renormalized_entropy(variants["true"][span]["map"])
                frames.append(record)
                images.append(model_image)
        if not frames:
            raise ValueError(f"episode {plan.episode}: no frames on the stride grid before the wait end")
        print(
            f"episode {plan.episode} ({plan.prompt} / {plan.side}): {len(frames)} frames replayed "
            f"in {time.monotonic() - started:.1f}s"
        )
        return {
            "plan": plan,
            "frames": frames,
            "images": images,
            "maps": maps,
            "token_maps": token_maps,
            "token_masks": token_masks,
            "span_texts": span_texts,
        }

    def _render(self, replay: dict[str, Any], path: Path) -> str:
        plan: _wa._EpisodePlan = replay["plan"]
        scales: dict[str, token_heatmap.ColorScale] = {}
        for span in SPAN_NAMES:
            true_series = replay["maps"][f"{span}_true"]
            cf_series = replay["maps"][f"{span}_cf"]
            scales[span] = _video_scale(true_series + cf_series)
            scales[f"{span}_diff"] = _video_scale(
                [np.abs(a.astype(np.float64) - b.astype(np.float64)) for a, b in zip(true_series, cf_series, strict=True)]
            )
        video_frames = []
        for index, (image, frame) in enumerate(zip(replay["images"], replay["frames"], strict=True)):
            span_maps = {
                span: {
                    "true": replay["maps"][f"{span}_true"][index],
                    "cf": replay["maps"][f"{span}_cf"][index],
                }
                for span in SPAN_NAMES
            }
            texts = {"instruction_image": f"f{frame['frame']} {frame['phase']}", "state_image": "top camera"}
            for span in SPAN_NAMES:
                texts[f"{span}_true"] = f"{span[:5]} TRUE top={frame[f'{span}_top_mass_true']:.1%}"
                texts[f"{span}_cf"] = f"{span[:5]} CF top={frame[f'{span}_top_mass_cf']:.1%}"
                texts[f"{span}_diff"] = f"|d| js={frame[f'{span}_js_true_cf']:.3f}"
            label = (
                f"ep{plan.episode} L{self.options.layer if self.options.layer is not None else self.model.memory_layer}"
                f" prompt->top attention | TRUE: {plan.prompt} vs CF: {plan.counterfactual}"
            )
            video_frames.append(prompt_grid_frame(image, span_maps, scales, texts, label))
        return token_heatmap.encode_mp4(video_frames, path, self.options.video_fps)

    @staticmethod
    def _phase_table(all_frames: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
        table: dict[str, dict[str, float]] = {}
        for phase in ("approach", "evidence", "retention", "waiting"):
            rows = [f for f in all_frames if f["phase"] == phase]
            if not rows:
                continue
            entry: dict[str, float] = {"frames": len(rows)}
            for key in (
                "instruction_top_mass_true",
                "instruction_top_mass_cf",
                "instruction_js_true_cf",
                "instruction_left_mass_true",
                "instruction_left_mass_cf",
                "instruction_entropy_true",
                "state_top_mass_true",
                "state_js_true_cf",
                "state_left_mass_true",
            ):
                entry[key] = float(np.mean([f[key] for f in rows]))
            table[phase] = entry
        return table

    def run(self) -> dict[str, Any]:
        print(f"pathway scalars: {self.scalars}")
        tasks = _wa._read_tasks(self.options.dataset_root)
        plans = apply_prompt_overrides(_wa._plan_episodes(self.options, self.data_config), self.options)
        print(f"replaying {len(plans)} episodes: {[(p.episode, p.prompt, p.side) for p in plans]}")

        self.options.output_dir.mkdir(parents=True)
        report: dict[str, Any] = {
            "schema": SCHEMA_VERSION,
            "checkpoint": str(self.options.checkpoint),
            "layer": self.options.layer if self.options.layer is not None else int(self.model.memory_layer),
            "head": self.options.head,
            "stride": self.stride,
            "pathway_scalars": self.scalars,
            "episodes": [],
        }
        every_frame: list[dict[str, Any]] = []
        for plan in plans:
            replay = self._replay(plan, tasks)
            stem = f"episode_{plan.episode:03d}"
            encoder = self._render(replay, self.options.output_dir / f"{stem}.mp4")
            np.savez_compressed(
                self.options.output_dir / f"{stem}_maps.npz",
                frames=np.asarray([f["frame"] for f in replay["frames"]], dtype=np.int32),
                **{key: np.stack(value) for key, value in replay["maps"].items()},
                **{f"tokens_{key}": np.stack(value) for key, value in replay["token_maps"].items()},
                **{f"mask_{key}": np.stack(value) for key, value in replay["token_masks"].items()},
            )
            report["episodes"].append(
                {
                    "episode": plan.episode,
                    "prompt": plan.prompt,
                    "counterfactual": plan.counterfactual,
                    "side": plan.side,
                    "evidence": list(plan.evidence),
                    "memory": list(plan.memory),
                    "video_encoder": encoder,
                    "span_texts": replay["span_texts"],
                    "phase_table": self._phase_table(replay["frames"]),
                    "frames": replay["frames"],
                }
            )
            every_frame.extend(replay["frames"])

        report["phase_table"] = self._phase_table(every_frame)
        (self.options.output_dir / "summary.json").write_text(json.dumps(report, indent=2))
        print(f"\n{'phase':>10} {'frames':>7} {'i_top':>7} {'i_top_cf':>9} {'i_js':>7} {'i_left':>7} {'s_top':>7} {'s_js':>7}")
        for phase, row in report["phase_table"].items():
            print(
                f"{phase:>10} {row['frames']:>7} {row['instruction_top_mass_true']:>7.3f} "
                f"{row['instruction_top_mass_cf']:>9.3f} {row['instruction_js_true_cf']:>7.4f} "
                f"{row['instruction_left_mass_true']:>7.3f} {row['state_top_mass_true']:>7.3f} "
                f"{row['state_js_true_cf']:>7.4f}"
            )
        print(f"wrote {self.options.output_dir}/summary.json")
        return report


SWEEP_SCHEMA_VERSION = "openpi.v33.prompt_attention_layer_sweep.v1"


class LayerSweepRunner(PromptAttentionRunner):
    """Every gemma block in one pass: at which depth does instruction->image routing live?

    The capture already materializes all layers' attention, so sweeping depth costs the same
    two forwards per frame as the single-layer diagnostic. Per episode it renders two grid
    videos (one tile per block: the TRUE instruction-row map, and the |TRUE-CF| map) and the
    summary reports, per layer and phase, the instruction-row masses, TRUE-vs-CF divergence,
    and the side-corrected steer -- the number that says "the swap moved attention toward the
    instructed bin", which is what a conditioner tap cares about.

    Subclasses can sweep a different axis (see :class:`HeadSweepRunner`); frame records and
    the report always call the sweep index ``layer`` regardless of what it enumerates.
    """

    sweep_tag = "L"
    sweep_name = "layer"
    schema = SWEEP_SCHEMA_VERSION

    def _sweep_step(self, observation: Any) -> tuple[dict[str, Any], int]:
        out = self._pstep(observation, layer=-1, head=self.options.head)
        return out, int(out["depth"])

    def _report_extras(self) -> dict[str, Any]:
        return {}

    def _replay(self, plan: _wa._EpisodePlan, tasks: dict[int, str]) -> dict[str, Any]:
        source = _wc._load_lerobot_sources(self.options.dataset_root, [plan.episode])[0]
        columns = ["image", "left_wrist_image", "right_wrist_image", "state", "frame_index", "task_index"]
        rows = pq.read_table(source.path, columns=columns).to_pylist()

        depth = 0
        frames: list[dict[str, Any]] = []  # one record per (frame, layer)
        frame_indices: list[int] = []
        images: list[np.ndarray] = []
        maps: dict[str, list[np.ndarray]] = {f"{span}_{variant}": [] for span in SPAN_NAMES for variant in ("true", "cf")}
        span_texts: dict[str, str] = {}
        started = time.monotonic()
        with self.model.capture_attention():
            for row in rows:
                raw_frame = int(row["frame_index"])
                if raw_frame % self.stride or raw_frame > plan.memory[1]:
                    continue
                observation_true, model_image = self._observation(row, raw_frame, plan.prompt)
                observation_cf, _ = self._observation(row, raw_frame, plan.counterfactual)
                phase = (
                    "evidence"
                    if plan.evidence[0] <= raw_frame <= plan.evidence[1]
                    else "waiting"
                    if raw_frame >= plan.memory[0]
                    else "retention"
                    if raw_frame > plan.evidence[1]
                    else "approach"
                )
                layered: dict[str, list[dict[str, Any]]] = {}
                for variant, observation in (("true", observation_true), ("cf", observation_cf)):
                    out, depth = self._sweep_step(observation)
                    top = np.asarray(out["prompt_to_top"], dtype=np.float64)
                    images_mass = np.asarray(out["prompt_to_images_mass"], dtype=np.float64)
                    text_mass = np.asarray(out["prompt_to_text_mass"], dtype=np.float64)
                    layered[variant] = [
                        self._variant(
                            {
                                "prompt_to_top": top[:, index],
                                "prompt_to_images_mass": images_mass[:, index],
                                "prompt_to_text_mass": text_mass[:, index],
                            },
                            observation,
                        )
                        for index in range(depth)
                    ]
                for span in SPAN_NAMES:
                    for variant in ("true", "cf"):
                        maps[f"{span}_{variant}"].append(
                            np.stack([layered[variant][index][span]["map"] for index in range(depth)]).astype(
                                np.float16
                            )
                        )
                        span_texts[f"{span}_{variant}"] = layered[variant][0][span]["text"]
                for index in range(depth):
                    record: dict[str, Any] = {
                        "frame": raw_frame,
                        "layer": index,
                        "phase": phase,
                        "task": tasks[int(row["task_index"])],
                    }
                    for span in SPAN_NAMES:
                        for variant in ("true", "cf"):
                            entry = layered[variant][index][span]
                            record[f"{span}_top_mass_{variant}"] = entry["top_mass"]
                            record[f"{span}_images_mass_{variant}"] = entry["images_mass"]
                            record[f"{span}_text_mass_{variant}"] = entry["text_mass"]
                            record[f"{span}_left_mass_{variant}"] = _wa.left_half_mass(entry["map"][None])
                        record[f"{span}_js_true_cf"] = map_js(
                            layered["true"][index][span]["map"], layered["cf"][index][span]["map"]
                        )
                        record[f"{span}_entropy_true"] = renormalized_entropy(layered["true"][index][span]["map"])
                    frames.append(record)
                frame_indices.append(raw_frame)
                images.append(model_image)
        if not frames:
            raise ValueError(f"episode {plan.episode}: no frames on the stride grid before the wait end")
        print(
            f"episode {plan.episode} ({plan.prompt} / {plan.side}): {len(frame_indices)} frames x {depth} "
            f"{self.sweep_name}s replayed in {time.monotonic() - started:.1f}s"
        )
        return {
            "plan": plan,
            "depth": depth,
            "frames": frames,
            "frame_indices": frame_indices,
            "images": images,
            "maps": maps,
            "span_texts": span_texts,
        }

    def _render_single_views(self, replay: dict[str, Any], stem: str) -> dict[str, str]:
        """One plain single-view video per swept slice: camera + that slice's TRUE attention."""
        plan: _wa._EpisodePlan = replay["plan"]
        depth = replay["depth"]
        by_frame_layer = {(f["frame"], f["layer"]): f for f in replay["frames"]}
        scale = self.options.view_scale
        images = replay["images"]
        if scale != 1:
            images = [
                cv2.resize(image, (image.shape[1] * scale, image.shape[0] * scale), interpolation=cv2.INTER_LINEAR)
                for image in images
            ]
        encoders = {}
        for layer in range(depth):
            video_frames = []
            for index, raw_frame in enumerate(replay["frame_indices"]):
                record = by_frame_layer[(raw_frame, layer)]
                values = replay["maps"]["instruction_true"][index][layer].astype(np.float64)
                label = (
                    f"ep{plan.episode} f{raw_frame} {record['phase']} {self.sweep_tag}{layer} "
                    f"top={record['instruction_top_mass_true']:.0%} | {plan.prompt}"
                )
                video_frames.append(single_view_frame(images[index], values, label))
            encoders[f"{self.sweep_name}{layer}"] = token_heatmap.encode_mp4(
                video_frames,
                self.options.output_dir / f"{stem}_{self.sweep_name}{layer:02d}_single.mp4",
                self.options.video_fps,
            )
        return encoders

    def _render_sweep(self, replay: dict[str, Any], stem: str) -> dict[str, str]:
        if self.options.single_view:
            return self._render_single_views(replay, stem)
        plan: _wa._EpisodePlan = replay["plan"]
        depth = replay["depth"]
        by_frame_layer = {(f["frame"], f["layer"]): f for f in replay["frames"]}
        encoders = {}
        for kind in ("true", "diff"):
            video_frames = []
            for index, (image, raw_frame) in enumerate(
                zip(replay["images"], replay["frame_indices"], strict=True)
            ):
                true_maps = replay["maps"]["instruction_true"][index].astype(np.float64)
                cf_maps = replay["maps"]["instruction_cf"][index].astype(np.float64)
                layer_maps = true_maps if kind == "true" else np.abs(true_maps - cf_maps)
                texts = []
                for layer in range(depth):
                    record = by_frame_layer[(raw_frame, layer)]
                    if kind == "true":
                        texts.append(f"{self.sweep_tag}{layer} {record['instruction_top_mass_true']:.0%}")
                    else:
                        texts.append(f"{self.sweep_tag}{layer} js={record['instruction_js_true_cf']:.2f}")
                phase = by_frame_layer[(raw_frame, 0)]["phase"]
                label = (
                    f"ep{plan.episode} f{raw_frame} {phase} | instruction rows "
                    f"{'TRUE' if kind == 'true' else '|TRUE-CF|'} per {self.sweep_name} | "
                    f"TRUE: {plan.prompt} vs CF: {plan.counterfactual}"
                )
                video_frames.append(layer_grid_frame(image, layer_maps, texts, label))
            encoders[kind] = token_heatmap.encode_mp4(
                video_frames,
                self.options.output_dir / f"{stem}_layers_{kind}.mp4",
                self.options.video_fps,
            )
        return encoders

    @staticmethod
    def _layer_phase_tables(all_frames: list[dict[str, Any]], depth: int) -> dict[int, dict[str, dict[str, float]]]:
        return {
            layer: LayerSweepRunner._phase_table([f for f in all_frames if f["layer"] == layer])
            for layer in range(depth)
        }

    def run(self) -> dict[str, Any]:
        print(f"pathway scalars: {self.scalars}")
        tasks = _wa._read_tasks(self.options.dataset_root)
        plans = apply_prompt_overrides(_wa._plan_episodes(self.options, self.data_config), self.options)
        print(f"replaying {len(plans)} episodes: {[(p.episode, p.prompt, p.side) for p in plans]}")

        self.options.output_dir.mkdir(parents=True)
        report: dict[str, Any] = {
            "schema": self.schema,
            "checkpoint": str(self.options.checkpoint),
            "head": self.options.head,
            "stride": self.stride,
            "pathway_scalars": self.scalars,
            "episodes": [],
            **self._report_extras(),
        }
        every_frame: list[dict[str, Any]] = []
        steer: dict[int, list[float]] = {}
        depth = 0
        for plan in plans:
            replay = self._replay(plan, tasks)
            depth = replay["depth"]
            stem = f"episode_{plan.episode:03d}"
            encoders = self._render_sweep(replay, stem)
            np.savez_compressed(
                self.options.output_dir / f"{stem}_maps.npz",
                frames=np.asarray(replay["frame_indices"], dtype=np.int32),
                **{key: np.stack(value) for key, value in replay["maps"].items()},
            )
            # per-episode evidence steer, one number per layer, sign-corrected by target side
            for layer in range(depth):
                evidence = [f for f in replay["frames"] if f["layer"] == layer and f["phase"] == "evidence"]
                if evidence:
                    steer.setdefault(layer, []).append(
                        side_corrected_steer(
                            float(np.mean([f["instruction_left_mass_true"] for f in evidence])),
                            float(np.mean([f["instruction_left_mass_cf"] for f in evidence])),
                            plan.side,
                        )
                    )
            report["episodes"].append(
                {
                    "episode": plan.episode,
                    "prompt": plan.prompt,
                    "counterfactual": plan.counterfactual,
                    "side": plan.side,
                    "evidence": list(plan.evidence),
                    "memory": list(plan.memory),
                    "video_encoder": encoders,
                    "span_texts": replay["span_texts"],
                    "layer_phase_tables": self._layer_phase_tables(replay["frames"], depth),
                }
            )
            every_frame.extend(replay["frames"])

        report["depth"] = depth
        report["layer_phase_tables"] = self._layer_phase_tables(every_frame, depth)
        report["evidence_steer_by_layer"] = {
            layer: {"mean": float(np.mean(values)), "per_episode": values} for layer, values in steer.items()
        }
        (self.options.output_dir / "summary.json").write_text(json.dumps(report, indent=2))
        print(f"\nevidence phase, all episodes ({len(plans)}):")
        print(f"{self.sweep_name:>6} {'i_top':>7} {'i_js':>7} {'steer':>7} {'s_top':>7} {'s_js':>7}")
        for layer in range(depth):
            table = report["layer_phase_tables"][layer].get("evidence")
            if table is None:
                continue
            steer_mean = report["evidence_steer_by_layer"].get(layer, {}).get("mean", float("nan"))
            print(
                f"{layer:>6} {table['instruction_top_mass_true']:>7.3f} {table['instruction_js_true_cf']:>7.4f} "
                f"{steer_mean:>7.3f} {table['state_top_mass_true']:>7.3f} {table['state_js_true_cf']:>7.4f}"
            )
        print(f"wrote {self.options.output_dir}/summary.json")
        return report


HEAD_SWEEP_SCHEMA_VERSION = "openpi.v33.prompt_attention_head_sweep.v1"


class HeadSweepRunner(LayerSweepRunner):
    """Every attention head of ONE layer: is there a routing head the head-mean dilutes?

    The head-mean can hide a single head that routes sharply to the instructed bin behind
    seven diffuse or sink heads. This sweep reuses the layer-sweep machinery with heads as
    the sweep axis (the ``layer`` field of records/report then indexes heads); the layer is
    ``options.layer`` (None = the model's memory_layer).
    """

    sweep_tag = "H"
    sweep_name = "head"
    schema = HEAD_SWEEP_SCHEMA_VERSION

    def _sweep_step(self, observation: Any) -> tuple[dict[str, Any], int]:
        out = self._pstep(observation, layer=self.options.layer, head=-1)
        return out, int(out["num_heads"])

    def _report_extras(self) -> dict[str, Any]:
        layer = self.options.layer if self.options.layer is not None else int(self.model.memory_layer)
        return {"layer": layer}
