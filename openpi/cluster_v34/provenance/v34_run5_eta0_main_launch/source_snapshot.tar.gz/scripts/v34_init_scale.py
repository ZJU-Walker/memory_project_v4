"""v3.4 init measurements (V34_PLAN_final.md 3.4 note + section 9 step 3).

Measures, ON THE ACTUAL v3.4 INITIALIZATION (fresh init + official pi05_base graft -- exactly
what training step 0 sees):

  * c   -- the valid-position layer-8 residual-stream RMS (per token over channels), the
           target scale of the plan-5.6 normalized injection (v3.3-checkpoint prior: 12.4);
  * tau -- the floor of max(rms(retrieved), tau), set from the POST-WRITE retrieval RMS
           distribution after the 5.7 memory-MLP fix (the old 0.12 retrieved scale was a
           property of the bloated un-normalized MLP);
  * the write-clip statistics at init on REAL frames (the on-model check of the Stage-0
    result: the raw inner gradients must be O(1), not hundreds).

Replays real training sequences (the same loader the run uses, heldout episodes excluded) at
the training write cadence: per step, the early-only interface (blocks 0..8, conditioned
writer, pre-write read) followed by the memory write.

Run on a GPU node:
    uv run scripts/v34_init_scale.py --config pi05_yam_mem_v34 --batches 4 --batch_size 4
"""

# ruff: noqa: I001  - pyarrow-before-openpi import order is load-bearing
import pyarrow.parquet as pq  # noqa: F401
import torch  # noqa: F401

import argparse
import dataclasses
import logging

import flax.nnx as nnx
import jax
import jax.numpy as jnp
import numpy as np

import openpi.models.model as _model
import openpi.training.config as _config
import openpi.training.data_loader as _data_loader

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")


def build_init_model(config: _config.TrainConfig, *, bf16_tower: bool = False):
    """The exact training initialization: fresh params overwritten by the pi05_base subset.

    ``bf16_tower`` casts the PaliGemma/SigLIP parameters to bfloat16 on load (the training
    compute dtype; halves device memory so the measurement fits a 24GB card). The memory
    subsystem and all v3.4 params stay float32.
    """
    import flax.traverse_util as traverse_util

    rng = jax.random.key(config.seed)
    _, init_rng = jax.random.split(rng)
    _, model_rng = jax.random.split(init_rng)
    model = config.model.create(model_rng)
    graphdef, state = nnx.split(model)
    params_shape = jax.tree.map(lambda x: jax.ShapeDtypeStruct(x.shape, x.dtype), state.to_pure_dict())
    loaded = config.weight_loader.load(params_shape)
    # Exactly train.py's merge: keep ONLY the actually-loaded arrays (the ShapeDtypeStruct
    # placeholders mark params the checkpoint does not contain -- fresh init, and the flax
    # None-bias slots must never be materialized).
    flat_loaded = {
        key: value
        for key, value in traverse_util.flatten_dict(loaded, sep="/").items()
        if not isinstance(value, jax.ShapeDtypeStruct) and value is not None
    }
    flat_loaded = {
        key: jnp.asarray(value, dtype=jnp.bfloat16)
        if bf16_tower and key.startswith("PaliGemma/") and value.dtype == np.float32
        else jnp.asarray(value)
        for key, value in flat_loaded.items()
    }
    state.replace_by_pure_dict(traverse_util.unflatten_dict(flat_loaded, sep="/"))
    return nnx.merge(graphdef, state)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="pi05_yam_mem_v34")
    parser.add_argument("--batches", type=int, default=4)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--bf16_tower", action="store_true", help="bf16 PaliGemma params (fits a 24GB card)")
    args = parser.parse_args()

    config = _config.get_config(args.config)
    config = dataclasses.replace(config, batch_size=args.batch_size, num_workers=2)
    model = build_init_model(config, bf16_tower=args.bf16_tower)
    model.eval()
    logging.info("model initialized (pi05_base graft + fresh v3.4 params)")

    loader = _data_loader.create_data_loader(config, shuffle=True, num_batches=args.batches)

    import openpi.shared.nnx_utils as nnx_utils

    interface_step = nnx_utils.module_jit(model.v32_memory_interface_step)
    write_step = nnx_utils.module_jit(model.memory.write)

    def interface(obs_dict, state):
        obs = _model.Observation.from_dict(obs_dict)
        out = interface_step(obs, state)
        new_state, write_aux = write_step(state, out["write_tokens"])
        return new_state, {
            "h8_valid_rms": out["h8_valid_rms"],
            "retrieved_rms": out["retrieved_rms"],
            "memory_token_rms": out["memory_token_rms"],
            "grad_norm": write_aux["grad_norm"],
            "clip_factor": write_aux["clip_factor"],
            "surprise": write_aux["surprise"],
        }

    h8_rms, post_write_rms, first_read_rms, grad_norms, token_rms = [], [], [], [], []
    for batch_index, (obs, _actions) in enumerate(loader):
        b, t = obs.seq_step_mask.shape
        state = model.memory.init_state(b)
        valid = np.asarray(obs.seq_step_mask)
        for step in range(t):
            obs_dict = {
                "image": {k: v[:, step] for k, v in obs.images.items()},
                "image_mask": {k: v[:, step] for k, v in obs.image_masks.items()},
                "state": obs.state[:, step],
                "tokenized_prompt": obs.tokenized_prompt[:, step],
                "tokenized_prompt_mask": obs.tokenized_prompt_mask[:, step],
                "token_state_mask": obs.token_state_mask[:, step],
            }
            state, aux = interface(obs_dict, state)
            live = valid[:, step]
            if not live.any():
                break
            h8_rms.extend(np.asarray(aux["h8_valid_rms"])[live].tolist())
            token_rms.extend(np.asarray(aux["memory_token_rms"])[live].tolist())
            grad_norms.extend(np.asarray(aux["grad_norm"])[live].tolist())
            target = post_write_rms if step >= 1 else first_read_rms
            target.extend(np.asarray(aux["retrieved_rms"])[live].tolist())
        logging.info(f"batch {batch_index}: T={t}, frames so far={len(h8_rms)}")

    h8 = np.asarray(h8_rms)
    ret = np.asarray(post_write_rms)
    grads = np.asarray(grad_norms)
    print("\n================ v3.4 INIT SCALE MEASUREMENTS ================")
    print(f"frames measured: {len(h8)} (post-write reads: {len(ret)})")
    print(f"c  (h8 valid RMS):      mean {h8.mean():.3f}  median {np.median(h8):.3f}  p5 {np.percentile(h8, 5):.3f}  p95 {np.percentile(h8, 95):.3f}")
    print(f"fresh-read RMS (t=0):   max {np.max(first_read_rms):.3e}  (must be ~0: zero-init output layer)")
    print(
        "post-write retrieved RMS: "
        f"p5 {np.percentile(ret, 5):.4f}  p25 {np.percentile(ret, 25):.4f}  median {np.median(ret):.4f}  "
        f"p75 {np.percentile(ret, 75):.4f}  p95 {np.percentile(ret, 95):.4f}"
    )
    print(f"injected token RMS (current c/tau, tanh(0) gate): max {np.max(token_rms):.3e} (must be exactly 0)")
    print(f"write grad norms at init: median {np.median(grads):.3f}  p95 {np.percentile(grads, 95):.3f}  max {grads.max():.3f}")
    print(f"clip fraction (>1): {float(np.mean(grads > 1.0)):.3f}")
    recommended_tau = 0.5 * float(np.median(ret))
    print("\nRecommended config values:")
    print(f"  memory_injection_c   = {float(np.median(h8)):.2f}")
    print(f"  memory_injection_tau = {recommended_tau:.4f}   (0.5 x median post-write retrieved RMS)")
    print("Update pi05_yam_mem_v34 in src/openpi/training/config.py with these before training.")


if __name__ == "__main__":
    main()
