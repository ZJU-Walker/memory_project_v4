"""Re-render single-view prompt-attention videos from a previous run's NPZ files -- CPU only.

One tile per frame: the top camera under the requested span's attention overlay (per-frame-max
JET). No model or GPU is needed; camera frames are re-decoded from the dataset and the maps
come from the saved ``episode_*_maps.npz``.

Usage (after scripts/v33_prompt_attention.py has produced an output dir):
    uv run scripts/v33_prompt_attention_single_view.py \
        --npz_dir diagnostic_outputs/v33_prompt_attention/6500 \
        --dataset_root ~/.cache/huggingface/lerobot/yam/bin_memory_0816_subtask

Layer-sweep NPZs ([frames, layers, 256]) additionally need ``--layer``.
"""

import dataclasses
from pathlib import Path
import re

import tyro

from openpi.diagnostics import v33_prompt_attention as pa


@dataclasses.dataclass(frozen=True)
class Options:
    npz_dir: Path
    dataset_root: Path
    episodes: tuple[int, ...] = ()  # empty = every episode_*_maps.npz in npz_dir
    span: str = "instruction"
    # "true"/"cf" render the plain overlay; "diff" renders the SIGNED TRUE-CF effect
    # (red = attention gained under the true instruction, blue = lost).
    variant: str = "true"
    layer: int | None = None  # required for layer-sweep NPZs, forbidden otherwise
    fps: float = 4.0
    scale: int = 2

    def __post_init__(self) -> None:
        object.__setattr__(self, "npz_dir", Path(self.npz_dir).expanduser().resolve())
        object.__setattr__(self, "dataset_root", Path(self.dataset_root).expanduser().resolve())
        if self.span not in pa.SPAN_NAMES:
            raise ValueError(f"span must be one of {pa.SPAN_NAMES}")
        if self.variant not in ("true", "cf", "diff"):
            raise ValueError("variant must be 'true', 'cf', or 'diff'")
        if self.scale < 1:
            raise ValueError("scale must be at least 1")


def main(options: Options) -> None:
    pattern = re.compile(r"episode_(\d+)_maps\.npz$")
    found = sorted(
        (int(match.group(1)), path)
        for path in options.npz_dir.glob("episode_*_maps.npz")
        if (match := pattern.search(path.name))
    )
    if options.episodes:
        wanted = set(options.episodes)
        found = [(episode, path) for episode, path in found if episode in wanted]
        missing = wanted - {episode for episode, _ in found}
        if missing:
            raise FileNotFoundError(f"no episode_*_maps.npz in {options.npz_dir} for episodes {sorted(missing)}")
    if not found:
        raise FileNotFoundError(f"no episode_*_maps.npz files in {options.npz_dir}")

    layer_tag = "" if options.layer is None else f"_L{options.layer}"
    for episode, npz_path in found:
        output = options.npz_dir / f"episode_{episode:03d}_{options.span}_{options.variant}{layer_tag}_single.mp4"
        encoder = pa.single_view_from_npz(
            npz_path,
            options.dataset_root,
            episode,
            output,
            span=options.span,
            variant=options.variant,
            layer=options.layer,
            fps=options.fps,
            scale=options.scale,
        )
        print(f"wrote {output} ({encoder})")


if __name__ == "__main__":
    main(tyro.cli(Options))
