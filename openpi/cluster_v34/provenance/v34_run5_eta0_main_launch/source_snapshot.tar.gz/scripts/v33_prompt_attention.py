"""Driver for the prompt->top-camera attention diagnostic (see openpi.diagnostics.v33_prompt_attention).

Renders, per episode, an MP4 of how the instruction words and the state digits attend to the
top camera at the memory tap layer, under the TRUE and counterfactual instruction.

Usage:
    uv run scripts/v33_prompt_attention.py \
        --checkpoint checkpoints/pi05_yam_mem_v33/v33_run1/6500 \
        --dataset_root ~/.cache/huggingface/lerobot/yam/bin_memory_0816_subtask \
        --output_dir diagnostic_outputs/v33_prompt_attention/6500

``--layer -1`` sweeps every gemma block in the same two forwards per frame and renders
per-layer grid videos plus a per-layer steer table instead of the single-layer triptych.
``--head -1`` does the same across the 8 heads of one layer (default: the memory tap layer).
"""

import tyro

from openpi.diagnostics.v33_prompt_attention import HeadSweepRunner
from openpi.diagnostics.v33_prompt_attention import LayerSweepRunner
from openpi.diagnostics.v33_prompt_attention import Options
from openpi.diagnostics.v33_prompt_attention import PromptAttentionRunner

if __name__ == "__main__":
    options = tyro.cli(Options)
    if options.layer == -1:
        runner_class = LayerSweepRunner
    elif options.head == -1:
        runner_class = HeadSweepRunner
    else:
        runner_class = PromptAttentionRunner
    runner_class(options).run()
