"""Run the CPU-efficient v3.3 memory-interface replay.

Example:
    uv run scripts/v33_memory_interface.py \
        --checkpoint checkpoints/pi05_yam_mem_v33/v33_run1/6500 \
        --dataset-root ~/.cache/huggingface/lerobot/yam/bin_memory_0816_subtask \
        --output-dir diagnostic_outputs/v33_memory_interface/6500
"""

import tyro

from openpi.diagnostics.v33_memory_interface import Options
from openpi.diagnostics.v33_memory_interface import V33MemoryInterfaceRunner

if __name__ == "__main__":
    V33MemoryInterfaceRunner(tyro.cli(Options)).run()
