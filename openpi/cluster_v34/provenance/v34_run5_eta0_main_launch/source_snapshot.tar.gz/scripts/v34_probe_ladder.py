"""CLI for the v3.4 offline probe ladder (V34_PLAN_final.md Section 6).

Run at every ~2.5k-step checkpoint, in ladder order, BEFORE trusting any behavioral number:

    uv run scripts/v34_probe_ladder.py \\
        --checkpoint checkpoints/pi05_yam_mem_v34/<exp>/<step> \\
        --dataset_root ~/.cache/huggingface/lerobot/yam/bin_memory_0816_subtask \\
        --output_dir diagnostic_outputs/v34_probe_ladder/<step>
"""

# ruff: noqa: I001 - the pyarrow-before-openpi import order is load-bearing
import pyarrow.parquet as pq  # noqa: F401

import dataclasses
import pathlib

import tyro

import openpi.diagnostics.v34_probe_ladder as _ladder


@dataclasses.dataclass
class Args:
    checkpoint: str
    dataset_root: str
    output_dir: str
    config: str = "pi05_yam_mem_v34"
    episodes: tuple[int, ...] | None = None
    heldout: tuple[int, ...] = _ladder.DEFAULT_HELDOUT
    stride: int = 15


def main(args: Args) -> None:
    _ladder.run(
        _ladder.Options(
            checkpoint=str(pathlib.Path(args.checkpoint).expanduser()),
            dataset_root=str(pathlib.Path(args.dataset_root).expanduser()),
            output_dir=args.output_dir,
            config=args.config,
            episode_indices=args.episodes,
            heldout_episodes=args.heldout,
            stride=args.stride,
        )
    )


if __name__ == "__main__":
    main(tyro.cli(Args))
